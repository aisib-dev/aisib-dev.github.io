<?php
/**
 * The parish dashboard: big buttons for a non-technical priest, a restricted role, received entries.
 *
 * - Role `candela_editor_parohie`: write and publish posts, upload photos, read form entries, edit the
 *   schedule. No plugins, themes, settings, users.
 * - Page «Panoul parohiei» (start page after login for that role), buttons from `candela_butoane_panou`.
 * - Page «Primite» (entries of a form type): read, mark as read, delete, print.
 * - Simplified admin for the role: fewer menus, fewer blocks, default category from the button pressed.
 *
 * @package Candela\Core
 */

namespace Candela\Core\Panou;

use Candela\Core\Modul;
use Candela\Core\Formulare\Formulare;

/**
 * Dashboard module.
 */
final class Panou implements Modul {

	public const ROL       = 'candela_editor_parohie';
	public const CAP_INTR  = 'candela_formulare';
	public const CAP_PROG  = 'candela_program';
	public const PAGINA    = 'candela-panou';
	public const INTRARI   = 'candela-intrari';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'meniu' ), 5 );
		add_action( 'admin_menu', array( $this, 'meniu_simplu' ), 999 );
		add_filter( 'login_redirect', array( $this, 'dupa_login' ), 10, 3 );
		add_filter( 'option_default_category', array( $this, 'categorie_implicita' ) );
		add_filter( 'allowed_block_types_all', array( $this, 'blocuri_permise' ), 10, 2 );
		add_action( 'admin_post_candela_intrari', array( $this, 'actiune_intrari' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'stil' ) );
	}

	/**
	 * Creates the role and gives the custom capabilities to administrators and editors.
	 * Called on plugin activation (roles are stored in the database).
	 */
	public static function roluri(): void {
		remove_role( self::ROL );
		add_role(
			self::ROL,
			__( 'Parish editor', 'candela-core' ),
			array(
				'read'                   => true,
				'upload_files'           => true,
				'edit_posts'             => true,
				'edit_published_posts'   => true,
				'publish_posts'          => true,
				'delete_posts'           => true,
				'delete_published_posts' => true,
				self::CAP_INTR           => true,
				self::CAP_PROG           => true,
			)
		);
		foreach ( array( 'administrator', 'editor' ) as $r ) {
			$rol = get_role( $r );
			if ( $rol ) {
				$rol->add_cap( self::CAP_INTR );
				$rol->add_cap( self::CAP_PROG );
			}
		}
	}

	/**
	 * Dashboard buttons. Each: eticheta, descriere, url, icon (dashicon), cap, contor (int|null).
	 *
	 * @return array
	 */
	public static function butoane(): array {
		$b = array(
			array(
				'eticheta'  => __( 'New announcement', 'candela-core' ),
				'descriere' => __( 'A short notice: schedule change, collection, gathering.', 'candela-core' ),
				'url'       => admin_url( 'post-new.php?candela_cat=anunturi' ),
				'icon'      => 'megaphone',
				'cap'       => 'edit_posts',
			),
			array(
				'eticheta'  => __( 'New article', 'candela-core' ),
				'descriere' => __( 'A word of help, a catechesis, a homily for the blog.', 'candela-core' ),
				'url'       => admin_url( 'post-new.php?candela_cat=articole' ),
				'icon'      => 'welcome-write-blog',
				'cap'       => 'edit_posts',
			),
			array(
				'eticheta'  => __( 'Add photos', 'candela-core' ),
				'descriere' => __( 'Photos from services and parish life.', 'candela-core' ),
				'url'       => admin_url( 'media-new.php' ),
				'icon'      => 'format-gallery',
				'cap'       => 'upload_files',
			),
		);
		foreach ( Formulare::tipuri() as $tip => $def ) {
			$b[] = array(
				'eticheta'  => $def['eticheta_panou'] ?? $def['titlu'],
				'descriere' => __( 'Received through the website.', 'candela-core' ),
				'url'       => admin_url( 'admin.php?page=' . self::INTRARI . '&tip=' . $tip ),
				'icon'      => 'pomelnic' === $tip ? 'heart' : ( 'programare' === $tip ? 'calendar-alt' : 'email-alt' ),
				'cap'       => self::CAP_INTR,
				'contor'    => Formulare::necitite( $tip ),
				'ordine'    => 'pomelnic' === $tip ? 1 : ( 'programare' === $tip ? 2 : 50 ),
			);
		}
		/**
		 * Filters the dashboard buttons. Modules add their own (e.g. the weekly schedule).
		 *
		 * @since 0.1.0
		 * @param array $butoane Buttons: eticheta, descriere, url, icon, cap, contor?, ordine?.
		 */
		$b = (array) apply_filters( 'candela_butoane_panou', $b );
		$b = array_values( array_filter( $b, static fn( $x ) => current_user_can( $x['cap'] ?? 'read' ) ) );
		usort( $b, static fn( $x, $y ) => ( $x['ordine'] ?? 10 ) <=> ( $y['ordine'] ?? 10 ) );
		return $b;
	}

	/**
	 * Admin menu: the dashboard and the entries page.
	 */
	public function meniu(): void {
		$necitite = 0;
		foreach ( array_keys( Formulare::tipuri() ) as $tip ) {
			$necitite += Formulare::necitite( $tip );
		}
		$bula = $necitite ? ' <span class="awaiting-mod">' . (int) $necitite . '</span>' : '';
		add_menu_page( __( 'Parish dashboard', 'candela-core' ), __( 'Parish dashboard', 'candela-core' ) . $bula, 'edit_posts', self::PAGINA, array( $this, 'pagina' ), 'dashicons-building', 2 );
		add_submenu_page( self::PAGINA, __( 'Parish dashboard', 'candela-core' ), __( 'Start', 'candela-core' ), 'edit_posts', self::PAGINA, array( $this, 'pagina' ) );
		add_submenu_page( self::PAGINA, __( 'Received', 'candela-core' ), __( 'Received', 'candela-core' ), self::CAP_INTR, self::INTRARI, array( $this, 'pagina_intrari' ) );
	}

	/**
	 * Fewer menus for the parish editor.
	 */
	public function meniu_simplu(): void {
		if ( ! self::e_editor_parohie() ) {
			return;
		}
		// Updates are the maintainer's job; the parish editor never sees the "new version" nag.
		remove_action( 'admin_notices', 'update_nag', 3 );
		remove_action( 'admin_notices', 'maintenance_nag', 10 );
		foreach ( array( 'index.php', 'edit-comments.php', 'tools.php', 'profile.php' ) as $m ) {
			remove_menu_page( $m );
		}
	}

	/**
	 * Whether the current user is a parish editor (and not an administrator).
	 */
	public static function e_editor_parohie(): bool {
		$u = wp_get_current_user();
		return in_array( self::ROL, (array) $u->roles, true ) && ! in_array( 'administrator', (array) $u->roles, true );
	}

	/**
	 * After login, parish editors land on the dashboard.
	 *
	 * @param string           $catre   Redirect URL.
	 * @param string           $cerut   Requested URL.
	 * @param \WP_User|\WP_Error $user  User.
	 */
	public function dupa_login( $catre, $cerut, $user ) {
		if ( $user instanceof \WP_User && in_array( self::ROL, (array) $user->roles, true ) ) {
			return admin_url( 'admin.php?page=' . self::PAGINA );
		}
		return $catre;
	}

	/**
	 * «New announcement» / «New article» preselect the right category.
	 *
	 * @param mixed $implicit Default category ID.
	 */
	public function categorie_implicita( $implicit ) {
		global $pagenow;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only preselects a category in the editor.
		$slug = isset( $_GET['candela_cat'] ) ? sanitize_key( wp_unslash( $_GET['candela_cat'] ) ) : '';
		if ( is_admin() && 'post-new.php' === $pagenow && $slug ) {
			$t = get_category_by_slug( $slug );
			if ( $t ) {
				return (int) $t->term_id;
			}
		}
		return $implicit;
	}

	/**
	 * A short list of blocks for the parish editor (post editor only; the site editor is untouched).
	 *
	 * @param bool|string[]            $permise Allowed blocks.
	 * @param \WP_Block_Editor_Context $context Editor context.
	 * @return bool|string[]
	 */
	public function blocuri_permise( $permise, $context ) {
		if ( ! self::e_editor_parohie() || empty( $context->post ) ) {
			return $permise;
		}
		/**
		 * Filters the blocks a parish editor may use in posts.
		 *
		 * @since 0.1.0
		 * @param string[] $blocuri Block names.
		 */
		return (array) apply_filters(
			'candela_blocuri_editor',
			array( 'core/paragraph', 'core/heading', 'core/image', 'core/gallery', 'core/list', 'core/list-item', 'core/quote', 'core/buttons', 'core/button', 'core/separator', 'core/embed', 'core/video', 'core/file' )
		);
	}

	/**
	 * Admin styles of the dashboard pages.
	 *
	 * @param string $hook Admin page hook.
	 */
	public function stil( string $hook ): void {
		if ( false === strpos( $hook, self::PAGINA ) && false === strpos( $hook, self::INTRARI ) && false === strpos( $hook, 'candela-' ) ) {
			return;
		}
		wp_enqueue_style( 'candela-panou', plugins_url( 'assets/panou.css', CANDELA_CORE_DIR . '/candela-core.php' ), array(), CANDELA_CORE_VERSION );
	}

	/**
	 * The dashboard page.
	 */
	public function pagina(): void {
		$u = wp_get_current_user();
		?>
		<div class="wrap candela-panou">
			<h1><?php echo esc_html( sprintf( /* translators: %s: user display name. */ __( 'Good day, %s', 'candela-core' ), $u->display_name ) ); ?></h1>
			<p class="candela-panou__sub"><?php esc_html_e( 'What would you like to do today?', 'candela-core' ); ?></p>
			<div class="candela-panou__grila">
				<?php foreach ( self::butoane() as $b ) : ?>
					<a class="candela-panou__buton" href="<?php echo esc_url( $b['url'] ); ?>">
						<span class="dashicons dashicons-<?php echo esc_attr( $b['icon'] ?? 'admin-generic' ); ?>" aria-hidden="true"></span>
						<span class="candela-panou__eticheta"><?php echo esc_html( $b['eticheta'] ); ?>
							<?php if ( ! empty( $b['contor'] ) ) : ?>
								<span class="candela-panou__contor"><?php echo esc_html( sprintf( /* translators: %d: number of new entries. */ _n( '%d new', '%d new', (int) $b['contor'], 'candela-core' ), (int) $b['contor'] ) ); ?></span>
							<?php endif; ?>
						</span>
						<?php if ( ! empty( $b['descriere'] ) ) : ?>
							<span class="candela-panou__descriere"><?php echo esc_html( $b['descriere'] ); ?></span>
						<?php endif; ?>
					</a>
				<?php endforeach; ?>
			</div>
			<p class="candela-panou__vezi"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'See the website', 'candela-core' ); ?> &rarr;</a></p>
		</div>
		<?php
	}

	/**
	 * Entries of a form type: list, mark as read, delete, print.
	 */
	public function pagina_intrari(): void {
		if ( ! current_user_can( self::CAP_INTR ) ) {
			wp_die( esc_html__( 'You are not allowed to see this page.', 'candela-core' ) );
		}
		$tipuri = Formulare::tipuri();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- navigation only.
		$tip = isset( $_GET['tip'] ) ? sanitize_key( wp_unslash( $_GET['tip'] ) ) : (string) array_key_first( $tipuri );
		if ( ! isset( $tipuri[ $tip ] ) ) {
			$tip = (string) array_key_first( $tipuri );
		}
		$def     = $tipuri[ $tip ];
		$intrari = get_posts(
			array(
				'post_type'      => Formulare::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'no_found_rows'  => true,
				'meta_key'       => 'candela_tip', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- small, bounded set.
				'meta_value'     => $tip, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
		$url_act = static fn( string $act, int $id = 0 ) => wp_nonce_url( admin_url( 'admin-post.php?action=candela_intrari&act=' . $act . '&tip=' . $tip . ( $id ? '&id=' . $id : '' ) ), 'candela_intrari' );
		?>
		<div class="wrap candela-panou candela-intrari">
			<p class="candela-panou__inapoi"><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGINA ) ); ?>">&larr; <?php esc_html_e( 'Parish dashboard', 'candela-core' ); ?></a></p>
			<h1><?php echo esc_html( $def['eticheta_panou'] ?? $def['titlu'] ); ?></h1>
			<nav class="candela-intrari__file">
				<?php foreach ( $tipuri as $t => $d ) : ?>
					<a class="<?php echo $t === $tip ? 'activ' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::INTRARI . '&tip=' . $t ) ); ?>"><?php echo esc_html( $d['eticheta_panou'] ?? $d['titlu'] ); ?><?php $n = Formulare::necitite( $t ); echo $n ? ' (' . (int) $n . ')' : ''; ?></a>
				<?php endforeach; ?>
			</nav>
			<p class="candela-intrari__unelte">
				<button type="button" class="button button-primary button-hero" onclick="window.print()"><?php esc_html_e( 'Print', 'candela-core' ); ?></button>
				<?php if ( $intrari ) : ?>
					<a class="button button-hero" href="<?php echo esc_url( $url_act( 'citite' ) ); ?>"><?php esc_html_e( 'Mark all as read', 'candela-core' ); ?></a>
				<?php endif; ?>
			</p>
			<p class="candela-intrari__retentie">
				<?php
				$zile = (int) apply_filters( 'candela_retentie_zile', Formulare::setari()['retentie_zile'], $tip );
				/* translators: %d: number of days. */
				echo esc_html( sprintf( __( 'For privacy, entries are deleted automatically after %d days.', 'candela-core' ), $zile ) );
				?>
			</p>
			<?php if ( ! $intrari ) : ?>
				<p class="candela-intrari__gol"><?php esc_html_e( 'Nothing received yet.', 'candela-core' ); ?></p>
			<?php endif; ?>
			<div class="candela-intrari__lista">
				<?php foreach ( $intrari as $p ) : ?>
					<?php
					$date  = (array) get_post_meta( $p->ID, 'candela_date', true );
					$citit = (bool) get_post_meta( $p->ID, 'candela_citit', true );
					?>
					<article class="candela-intrare<?php echo $citit ? '' : ' candela-intrare--noua'; ?>">
						<header>
							<span class="candela-intrare__data"><?php echo esc_html( get_the_date( 'j F Y, H:i', $p ) ); ?></span>
							<?php if ( ! $citit ) : ?><span class="candela-intrare__nou"><?php esc_html_e( 'New', 'candela-core' ); ?></span><?php endif; ?>
						</header>
						<dl>
							<?php foreach ( $def['campuri'] as $c ) : ?>
								<?php if ( '' === (string) ( $date[ $c['nume'] ] ?? '' ) ) { continue; } ?>
								<dt><?php echo esc_html( $c['eticheta'] ); ?></dt>
								<dd class="candela-intrare__<?php echo esc_attr( $c['tip'] ); ?>"><?php echo nl2br( esc_html( $date[ $c['nume'] ] ) ); ?></dd>
							<?php endforeach; ?>
						</dl>
						<footer>
							<?php if ( ! $citit ) : ?>
								<a class="button" href="<?php echo esc_url( $url_act( 'citit', $p->ID ) ); ?>"><?php esc_html_e( 'Mark as read', 'candela-core' ); ?></a>
							<?php endif; ?>
							<a class="button candela-intrare__sterge" href="<?php echo esc_url( $url_act( 'sterge', $p->ID ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this entry for good?', 'candela-core' ) ); ?>')"><?php esc_html_e( 'Delete', 'candela-core' ); ?></a>
						</footer>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Mark as read / delete.
	 */
	public function actiune_intrari(): void {
		check_admin_referer( 'candela_intrari' );
		if ( ! current_user_can( self::CAP_INTR ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'candela-core' ) );
		}
		$act = sanitize_key( wp_unslash( $_GET['act'] ?? '' ) );
		$tip = sanitize_key( wp_unslash( $_GET['tip'] ?? '' ) );
		$id  = absint( $_GET['id'] ?? 0 );
		$e_intrare = static fn( int $i ) => $i && Formulare::CPT === get_post_type( $i );
		if ( 'citit' === $act && $e_intrare( $id ) ) {
			update_post_meta( $id, 'candela_citit', 1 );
		} elseif ( 'sterge' === $act && $e_intrare( $id ) ) {
			wp_delete_post( $id, true );
		} elseif ( 'citite' === $act ) {
			$ids = get_posts( array( 'post_type' => Formulare::CPT, 'fields' => 'ids', 'posts_per_page' => 500, 'meta_key' => 'candela_tip', 'meta_value' => $tip ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			foreach ( $ids as $i ) {
				update_post_meta( $i, 'candela_citit', 1 );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::INTRARI . '&tip=' . $tip ) );
		exit;
	}
}
