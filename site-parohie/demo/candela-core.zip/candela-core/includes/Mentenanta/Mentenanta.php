<?php
/**
 * Maintenance: the maintainer, not the parish editor, hears about problems first.
 *
 * - WordPress "recovery mode" e-mails (sent on a fatal PHP error) go to the maintainer address.
 * - A light health marker (`<meta name="candela-stare" content="ok">`) lets an outside monitor
 *   tell a working page from a blank or broken one that still answers 200.
 *
 * The address comes, in order, from the constant CANDELA_MENTENANTA_EMAIL (wp-config.php), the
 * option `candela_mentenanta` ['email'], or the `candela_mentenanta_email` filter.
 *
 * @package Candela\Core
 */

namespace Candela\Core\Mentenanta;

use Candela\Core\Modul;

/**
 * Maintenance module.
 */
final class Mentenanta implements Modul {

	public const OPTIUNE = 'candela_mentenanta';

	/**
	 * Hooks.
	 */
	public function register(): void {
		add_filter( 'recovery_mode_email', array( $this, 'email_recuperare' ), 10, 1 );
		add_action( 'wp_head', array( $this, 'marcaj' ), 1 );
	}

	/**
	 * Maintainer e-mail address, or '' when none is set.
	 */
	public static function email(): string {
		$email = defined( 'CANDELA_MENTENANTA_EMAIL' ) ? (string) constant( 'CANDELA_MENTENANTA_EMAIL' ) : '';
		if ( ! $email ) {
			$o     = get_option( self::OPTIUNE, array() );
			$email = is_array( $o ) ? (string) ( $o['email'] ?? '' ) : '';
		}
		/**
		 * Filters the maintainer e-mail address.
		 *
		 * @since 0.2.0
		 * @param string $email Address, possibly empty.
		 */
		$email = (string) apply_filters( 'candela_mentenanta_email', $email );
		return is_email( $email ) ? $email : '';
	}

	/**
	 * Sends the recovery-mode e-mail to the maintainer (the site admin stays in copy only if no
	 * maintainer is configured).
	 *
	 * @param array $mail Arguments for wp_mail(): to, subject, message, headers.
	 */
	public function email_recuperare( $mail ) {
		$email = self::email();
		if ( $email && is_array( $mail ) ) {
			$mail['to'] = $email;
		}
		return $mail;
	}

	/**
	 * Health marker for the outside monitor.
	 */
	public function marcaj(): void {
		echo '<meta name="candela-stare" content="ok">' . "\n";
	}
}
