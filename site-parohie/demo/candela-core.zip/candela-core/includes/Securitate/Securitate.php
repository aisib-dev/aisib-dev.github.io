<?php
/**
 * Security hardening that every parish site gets, with no settings to forget.
 *
 * - XML-RPC off (an old remote-publishing door, a favourite of password-guessing bots).
 * - No user enumeration: `?author=N` and the public `/wp/v2/users` REST list are closed to visitors,
 *   so bots cannot learn login names.
 * - Login errors do not say whether the user name or the password was wrong.
 * - Safe HTTP headers on public pages (no framing by other sites, no MIME sniffing, a strict referrer
 *   policy, no camera/microphone/location access).
 * - The theme/plugin file editor is off unless the site owner explicitly turns it back on.
 * - Application passwords (API keys) are off for the parish editor role.
 * - The WordPress version is not printed in the page head.
 *
 * Each measure can be undone with the `candela_securitate` filter (array of measure => bool).
 *
 * @package Candela\Core
 */

namespace Candela\Core\Securitate;

use Candela\Core\Modul;
use Candela\Core\Panou\Panou;

/**
 * Security module.
 */
final class Securitate implements Modul {

	/**
	 * Hooks, each behind its switch.
	 */
	public function register(): void {
		/**
		 * Filters which security measures are on.
		 *
		 * @since 0.2.0
		 * @param array<string, bool> $masuri Measure => enabled.
		 */
		$m = (array) apply_filters(
			'candela_securitate',
			array(
				'xmlrpc'        => true,
				'enumerare'     => true,
				'erori_login'   => true,
				'antete'        => true,
				'editor_fisier' => true,
				'parole_app'    => true,
				'versiune'      => true,
			)
		);

		if ( ! empty( $m['xmlrpc'] ) ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'xmlrpc_methods', '__return_empty_array' );
			if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
				status_header( 403 );
				exit;
			}
			add_filter( 'wp_headers', array( $this, 'fara_pingback' ) );
		}
		if ( ! empty( $m['enumerare'] ) ) {
			add_action( 'template_redirect', array( $this, 'blocheaza_autor' ), 1 );
			add_filter( 'rest_endpoints', array( $this, 'ascunde_utilizatori' ) );
		}
		if ( ! empty( $m['erori_login'] ) ) {
			add_filter( 'login_errors', array( $this, 'eroare_login' ) );
		}
		if ( ! empty( $m['antete'] ) ) {
			add_action( 'send_headers', array( $this, 'antete' ) );
		}
		if ( ! empty( $m['editor_fisier'] ) && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}
		if ( ! empty( $m['parole_app'] ) ) {
			add_filter( 'wp_is_application_passwords_available_for_user', array( $this, 'parole_app' ), 10, 2 );
		}
		if ( ! empty( $m['versiune'] ) ) {
			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string' );
		}
	}

	/**
	 * Drops the X-Pingback header.
	 *
	 * @param array $antete Headers.
	 */
	public function fara_pingback( $antete ) {
		unset( $antete['X-Pingback'] );
		return $antete;
	}

	/**
	 * `?author=N` for visitors goes to the home page instead of revealing the login name.
	 */
	public function blocheaza_autor(): void {
		if ( ! is_user_logged_in() && ( isset( $_GET['author'] ) || is_author() ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	/**
	 * Removes the public user list from the REST API for visitors.
	 *
	 * @param array $rute REST endpoints.
	 */
	public function ascunde_utilizatori( $rute ) {
		if ( ! is_user_logged_in() ) {
			foreach ( array_keys( $rute ) as $ruta ) {
				if ( 0 === strpos( $ruta, '/wp/v2/users' ) ) {
					unset( $rute[ $ruta ] );
				}
			}
		}
		return $rute;
	}

	/**
	 * One message for every failed login.
	 */
	public function eroare_login(): string {
		return esc_html__( 'The user name or the password is not correct.', 'candela-core' );
	}

	/**
	 * Safe headers for public pages (the admin keeps WordPress' own).
	 */
	public function antete(): void {
		if ( is_admin() || headers_sent() ) {
			return;
		}
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	}

	/**
	 * No application passwords for the parish editor.
	 *
	 * @param bool     $da   Available.
	 * @param \WP_User $user User.
	 */
	public function parole_app( $da, $user ) {
		return ( $user instanceof \WP_User && in_array( Panou::ROL, (array) $user->roles, true ) ) ? false : $da;
	}
}
