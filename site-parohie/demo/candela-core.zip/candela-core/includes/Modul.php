<?php
/**
 * Contract for every Candela module (core, verticals, third-party).
 *
 * @package Candela\Core
 */

namespace Candela\Core;

/**
 * A module registers its hooks in register(). It must not do work before WordPress' `init`
 * unless it only adds hooks.
 */
interface Modul {

	/**
	 * Adds the module's hooks.
	 */
	public function register(): void;
}
