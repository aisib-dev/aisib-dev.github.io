<?php
/**
 * Organisation data: filled in once, shown everywhere.
 *
 * Stored in one option, `candela_organizatie`. Exposed to blocks through the Block Bindings source
 * `candela/organizatie`, e.g. a paragraph bound with `{"source":"candela/organizatie","args":{"key":"telefon"}}`.
 *
 * @package Candela\Core
 */

namespace Candela\Core\Organizatie;

use Candela\Core\Modul;

/**
 * Organisation data module.
 */
final class Organizatie implements Modul {

	public const OPTIUNE = 'candela_organizatie';

	/**
	 * Allowed keys. Verticals may add keys through the `candela_campuri_organizatie` filter.
	 */
	public const CAMPURI = array(
		'nume',
		'hram',
		'eparhie',
		'adresa',
		'oras',
		'tara',
		'telefon',
		'email',
		'preot_nume',
		'preot_rang',
		'iban',
		'titular_cont',
		'cif',
		'facebook',
		'harta',
		'foto',
		'lat',
		'lng',
		'link_donatie',
	);

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'inregistreaza_setarea' ) );
		add_action( 'init', array( $this, 'inregistreaza_sursa' ) );
		add_action( 'init', array( $this, 'blocuri' ) );
		add_action( 'wp_head', array( $this, 'variabile_css' ), 5 );
	}

	/**
	 * Blocks that show organisation data: contact details and the phone quick-actions bar.
	 */
	public function blocuri(): void {
		register_block_type( CANDELA_CORE_DIR . '/blocks/contact' );
		register_block_type( CANDELA_CORE_DIR . '/blocks/bara-actiuni' );
		register_block_type( CANDELA_CORE_DIR . '/blocks/sprijin' );
		register_block_type( CANDELA_CORE_DIR . '/blocks/harta' );
	}

	/**
	 * Exposes the parish photo to the theme as a CSS variable (the theme decides where to show it).
	 */
	public function variabile_css(): void {
		$foto = self::get( 'foto' );
		if ( '' === $foto ) {
			return;
		}
		printf( "<style id=\"candela-variabile\">:root{--candela-foto:url('%s');}</style>\n", esc_url( $foto ) );
	}

	/**
	 * Keys accepted by the option.
	 *
	 * @return string[]
	 */
	public static function campuri(): array {
		/**
		 * Filters the organisation data keys.
		 *
		 * @since 0.1.0
		 * @param string[] $campuri Keys.
		 */
		return array_values( array_unique( (array) apply_filters( 'candela_campuri_organizatie', self::CAMPURI ) ) );
	}

	/**
	 * Reads one value (raw, unescaped). Empty string when missing.
	 *
	 * @param string $cheie Key.
	 */
	public static function get( string $cheie ): string {
		$date = get_option( self::OPTIUNE, array() );
		return is_array( $date ) && isset( $date[ $cheie ] ) ? (string) $date[ $cheie ] : '';
	}

	/**
	 * Registers the option (also exposed in the REST settings endpoint for the dashboard).
	 */
	public function inregistreaza_setarea(): void {
		$proprietati = array();
		foreach ( self::campuri() as $cheie ) {
			$proprietati[ $cheie ] = array( 'type' => 'string' );
		}
		register_setting(
			'candela',
			self::OPTIUNE,
			array(
				'type'              => 'object',
				'default'           => array(),
				'sanitize_callback' => array( self::class, 'curata' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => $proprietati,
						'additionalProperties' => false,
					),
				),
			)
		);
	}

	/**
	 * Keeps only known keys; plain text everywhere, except e-mail and URLs.
	 *
	 * @param mixed $valoare Submitted value.
	 * @return array<string, string>
	 */
	public static function curata( $valoare ): array {
		$out = array();
		if ( ! is_array( $valoare ) ) {
			return $out;
		}
		foreach ( self::campuri() as $cheie ) {
			if ( ! isset( $valoare[ $cheie ] ) ) {
				continue;
			}
			$v = (string) $valoare[ $cheie ];
			switch ( $cheie ) {
				case 'email':
					$out[ $cheie ] = sanitize_email( $v );
					break;
				case 'facebook':
				case 'harta':
				case 'foto':
				case 'link_donatie':
					$out[ $cheie ] = esc_url_raw( $v );
					break;
				case 'adresa':
					$out[ $cheie ] = sanitize_textarea_field( $v );
					break;
				default:
					$out[ $cheie ] = sanitize_text_field( $v );
			}
		}
		return $out;
	}

	/**
	 * Registers the Block Bindings source.
	 */
	public function inregistreaza_sursa(): void {
		if ( ! function_exists( 'register_block_bindings_source' ) ) {
			return;
		}
		register_block_bindings_source(
			'candela/organizatie',
			array(
				'label'              => __( 'Organisation data', 'candela-core' ),
				'get_value_callback' => array( self::class, 'valoare_legata' ),
			)
		);
	}

	/**
	 * Value for a bound block attribute. Escaped for HTML output.
	 *
	 * @param array $argumente Binding args; expects `key`.
	 * @return string|null
	 */
	public static function valoare_legata( array $argumente ): ?string {
		$cheie = isset( $argumente['key'] ) ? (string) $argumente['key'] : '';
		if ( ! in_array( $cheie, self::campuri(), true ) ) {
			return null;
		}
		return esc_html( self::get( $cheie ) );
	}
}
