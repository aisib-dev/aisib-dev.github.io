<?php
/**
 * Forms engine (ADR 0004): entries stored on the site, never sent to third parties.
 *
 * - Form types are declared through the `candela_formulare` filter (the core declares `contact`;
 *   verticals add their own, e.g. `pomelnic`, `programare`).
 * - Entries: private post type `candela_intrare`, meta `candela_tip`, `candela_date`, `candela_citit`.
 * - Spam: honeypot + signed time token + per-IP hourly limit (no cookies, no third parties).
 * - Privacy: explicit consent, notification e-mail without personal data, daily deletion after the
 *   retention period (`candela_retentie_zile`, default 40 days).
 *
 * @package Candela\Core
 */

namespace Candela\Core\Formulare;

use Candela\Core\Modul;
use Candela\Core\Organizatie\Organizatie;

/**
 * Forms module.
 */
final class Formulare implements Modul {

	public const CPT     = 'candela_intrare';
	public const OPTIUNE = 'candela_formulare_setari';
	public const CRON    = 'candela_curata_formulare';
	public const ACTIUNE = 'candela_formular';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'tip_continut' ) );
		add_action( 'init', array( $this, 'bloc' ) );
		add_action( 'init', array( $this, 'programeaza_curatarea' ) );
		add_action( self::CRON, array( self::class, 'curata' ) );
		add_action( 'admin_post_nopriv_' . self::ACTIUNE, array( $this, 'primeste' ) );
		add_action( 'admin_post_' . self::ACTIUNE, array( $this, 'primeste' ) );
	}

	/**
	 * Declared form types.
	 *
	 * @return array<string, array{titlu:string, campuri:array, consimtamant:string, buton:string, multumire:string, eticheta_panou:string}>
	 */
	public static function tipuri(): array {
		$tipuri = array(
			'contact' => array(
				'titlu'          => __( 'Message', 'candela-core' ),
				'eticheta_panou' => __( 'Messages', 'candela-core' ),
				'buton'          => __( 'Send the message', 'candela-core' ),
				'multumire'      => __( 'Thank you! Your message has been received.', 'candela-core' ),
				'consimtamant'   => __( 'I agree that the parish keeps this message in order to answer it. It is deleted automatically after the retention period.', 'candela-core' ),
				'campuri'        => array(
					array( 'nume' => 'nume', 'eticheta' => __( 'Your name', 'candela-core' ), 'tip' => 'text', 'obligatoriu' => true ),
					array( 'nume' => 'email', 'eticheta' => __( 'E-mail', 'candela-core' ), 'tip' => 'email', 'obligatoriu' => false ),
					array( 'nume' => 'telefon', 'eticheta' => __( 'Phone', 'candela-core' ), 'tip' => 'tel', 'obligatoriu' => false ),
					array( 'nume' => 'mesaj', 'eticheta' => __( 'Message', 'candela-core' ), 'tip' => 'textarea', 'obligatoriu' => true ),
				),
			),
		);
		/**
		 * Filters the declared form types.
		 *
		 * @since 0.1.0
		 * @param array $tipuri Form type => definition (titlu, eticheta_panou, buton, multumire, consimtamant, campuri).
		 */
		$tipuri = (array) apply_filters( 'candela_formulare', $tipuri );
		foreach ( $tipuri as $tip => &$def ) {
			/**
			 * Filters the fields of one form type.
			 *
			 * @since 0.1.0
			 * @param array $campuri Field definitions: nume, eticheta, tip (text|textarea|email|tel|date|select|radio), obligatoriu, optiuni, ajutor.
			 */
			$def['campuri'] = (array) apply_filters( "candela_campuri_formular_{$tip}", $def['campuri'] ?? array() );
		}
		return $tipuri;
	}

	/**
	 * Settings with defaults.
	 *
	 * @return array{email:string, retentie_zile:int}
	 */
	public static function setari(): array {
		$s = get_option( self::OPTIUNE, array() );
		return array(
			'email'         => is_email( $s['email'] ?? '' ) ? $s['email'] : ( Organizatie::get( 'email' ) ? Organizatie::get( 'email' ) : (string) get_option( 'admin_email' ) ),
			'retentie_zile' => max( 1, min( 365, (int) ( $s['retentie_zile'] ?? 40 ) ) ),
		);
	}

	/**
	 * Private post type for entries.
	 */
	public function tip_continut(): void {
		register_post_type(
			self::CPT,
			array(
				'label'           => __( 'Form entries', 'candela-core' ),
				'public'          => false,
				'show_ui'         => false,
				'show_in_rest'    => false,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'rewrite'         => false,
				'query_var'       => false,
			)
		);
		register_setting(
			'candela',
			self::OPTIUNE,
			array(
				'type'              => 'object',
				'default'           => array(),
				'sanitize_callback' => static fn( $v ) => array(
					'email'         => sanitize_email( $v['email'] ?? '' ),
					'retentie_zile' => max( 1, min( 365, (int) ( $v['retentie_zile'] ?? 40 ) ) ),
				),
			)
		);
	}

	/**
	 * Registers the form block.
	 */
	public function bloc(): void {
		register_block_type( CANDELA_CORE_DIR . '/blocks/formular' );
	}

	/**
	 * Daily deletion of expired entries.
	 */
	public function programeaza_curatarea(): void {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON );
		}
	}

	/**
	 * Deletes entries older than the retention period of their type.
	 *
	 * @return int Number of deleted entries.
	 */
	public static function curata(): int {
		$sterse = 0;
		$baza   = self::setari()['retentie_zile'];
		foreach ( array_keys( self::tipuri() ) as $tip ) {
			/**
			 * Filters the number of days entries of a form type are kept.
			 *
			 * @since 0.1.0
			 * @param int    $zile Days (default: the setting, 40).
			 * @param string $tip  Form type.
			 */
			$zile = max( 1, (int) apply_filters( 'candela_retentie_zile', $baza, $tip ) );
			$ids  = get_posts(
				array(
					'post_type'      => self::CPT,
					'post_status'    => 'any',
					'fields'         => 'ids',
					'posts_per_page' => 500,
					'no_found_rows'  => true,
					'date_query'     => array( array( 'before' => gmdate( 'Y-m-d H:i:s', time() - $zile * DAY_IN_SECONDS ), 'column' => 'post_date_gmt' ) ),
					'meta_key'       => 'candela_tip', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- small, bounded set.
					'meta_value'     => $tip, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				)
			);
			foreach ( $ids as $id ) {
				if ( wp_delete_post( $id, true ) ) {
					++$sterse;
				}
			}
		}
		return $sterse;
	}

	/**
	 * Signed time token: proves the form was rendered by this site some seconds before submission.
	 */
	public static function jeton(): string {
		$t = (string) time();
		return $t . '.' . substr( hash_hmac( 'sha256', $t, wp_salt( 'nonce' ) ), 0, 20 );
	}

	/**
	 * Checks the time token: at least 3 seconds old, at most 30 days (pages may be cached).
	 *
	 * @param string $jeton Token.
	 */
	public static function jeton_valid( string $jeton ): bool {
		$p = explode( '.', $jeton );
		if ( 2 !== count( $p ) || ! ctype_digit( $p[0] ) ) {
			return false;
		}
		$ok    = hash_equals( substr( hash_hmac( 'sha256', $p[0], wp_salt( 'nonce' ) ), 0, 20 ), $p[1] );
		$varsta = time() - (int) $p[0];
		return $ok && $varsta >= 3 && $varsta <= 30 * DAY_IN_SECONDS;
	}

	/**
	 * Handles a submission (classic POST, works without JavaScript and behind page caches).
	 */
	public function primeste(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- anonymous public form; protected by signed time token, honeypot and rate limit (nonces break behind page caches).
		$tip    = sanitize_key( wp_unslash( $_POST['candela_tip'] ?? '' ) );
		$tipuri = self::tipuri();
		$inapoi = wp_get_referer() ? wp_get_referer() : home_url( '/' );
		$inapoi = remove_query_arg( array( 'candela_trimis', 'candela_eroare' ), $inapoi );

		$eroare = '';
		if ( ! isset( $tipuri[ $tip ] ) ) {
			$eroare = 'tip';
		} elseif ( '' !== (string) ( $_POST['candela_site'] ?? '' ) ) {
			$eroare = 'spam'; // Honeypot filled: a robot.
		} elseif ( ! self::jeton_valid( sanitize_text_field( wp_unslash( $_POST['candela_t'] ?? '' ) ) ) ) {
			$eroare = 'timp';
		} elseif ( ! self::in_limita() ) {
			$eroare = 'limita';
		} elseif ( empty( $_POST['candela_acord'] ) ) {
			$eroare = 'acord';
		}

		$date = array();
		if ( '' === $eroare ) {
			foreach ( $tipuri[ $tip ]['campuri'] as $c ) {
				$v = self::curata_valoare( $c, wp_unslash( $_POST[ 'candela_' . $c['nume'] ] ?? '' ) );
				if ( ! empty( $c['obligatoriu'] ) && '' === $v ) {
					$eroare = 'camp';
					break;
				}
				$date[ $c['nume'] ] = $v;
			}
		}
		// phpcs:enable

		if ( '' !== $eroare ) {
			wp_safe_redirect( add_query_arg( 'candela_eroare', $eroare, $inapoi ) . '#candela-formular-' . $tip );
			exit;
		}

		$id = wp_insert_post(
			array(
				'post_type'   => self::CPT,
				'post_status' => 'publish',
				'post_title'  => $tipuri[ $tip ]['titlu'] . ' ' . wp_date( 'Y-m-d H:i' ),
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, 'candela_tip', $tip );
			update_post_meta( $id, 'candela_date', $date );
			update_post_meta( $id, 'candela_citit', 0 );
			self::notifica( $tip );
			/**
			 * Fires after a form entry has been stored.
			 *
			 * @since 0.1.0
			 * @param int    $id  Entry ID.
			 * @param string $tip Form type.
			 */
			do_action( 'candela_formular_primit', $id, $tip );
		}
		wp_safe_redirect( add_query_arg( 'candela_trimis', $tip, $inapoi ) . '#candela-formular-' . $tip );
		exit;
	}

	/**
	 * Sanitises one field value according to its type.
	 *
	 * @param array $c Field definition.
	 * @param mixed $v Raw value.
	 */
	public static function curata_valoare( array $c, $v ): string {
		$v = is_scalar( $v ) ? (string) $v : '';
		switch ( $c['tip'] ?? 'text' ) {
			case 'textarea':
				return mb_substr( sanitize_textarea_field( $v ), 0, 3000 );
			case 'email':
				return (string) sanitize_email( $v );
			case 'tel':
				return mb_substr( preg_replace( '/[^0-9+ ()\-]/', '', $v ), 0, 30 );
			case 'date':
				return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
			case 'select':
			case 'radio':
				// The form sends the option key (stable across languages); the label is stored.
				$optiuni = (array) ( $c['optiuni'] ?? array() );
				return array_key_exists( $v, $optiuni ) && '' !== $v ? (string) $optiuni[ $v ] : '';
			default:
				return mb_substr( sanitize_text_field( $v ), 0, 200 );
		}
	}

	/**
	 * At most 10 submissions per hour from one address (the address itself is not stored).
	 */
	private static function in_limita(): bool {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$k   = 'candela_rl_' . substr( hash_hmac( 'sha256', $ip . gmdate( 'YmdH' ), wp_salt( 'nonce' ) ), 0, 24 );
		$nr  = (int) get_transient( $k );
		if ( $nr >= 10 ) {
			return false;
		}
		set_transient( $k, $nr + 1, HOUR_IN_SECONDS );
		return true;
	}

	/**
	 * Notification without personal data: only the type and a link to the dashboard.
	 *
	 * @param string $tip Form type.
	 */
	private static function notifica( string $tip ): void {
		$tipuri = self::tipuri();
		$catre  = self::setari()['email'];
		if ( ! is_email( $catre ) ) {
			return;
		}
		$nume = $tipuri[ $tip ]['titlu'] ?? $tip;
		/* translators: %s: form type, e.g. "Pomelnic". */
		$subiect = sprintf( __( 'New on the parish website: %s', 'candela-core' ), $nume );
		$corp    = sprintf(
			/* translators: 1: form type, 2: dashboard link. */
			__( "A new entry has arrived (%1\$s).\n\nFor privacy, its content is not sent by e-mail. Open the parish dashboard to read it:\n%2\$s", 'candela-core' ),
			$nume,
			admin_url( 'admin.php?page=candela-intrari&tip=' . rawurlencode( $tip ) )
		);
		wp_mail( $catre, $subiect, $corp );
	}

	/**
	 * Unread entries of a type (for dashboard counters).
	 *
	 * @param string $tip Form type.
	 */
	public static function necitite( string $tip ): int {
		$q = new \WP_Query(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- small, bounded set.
					array( 'key' => 'candela_tip', 'value' => $tip ),
					array( 'key' => 'candela_citit', 'value' => '0' ),
				),
			)
		);
		return (int) $q->found_posts;
	}
}
