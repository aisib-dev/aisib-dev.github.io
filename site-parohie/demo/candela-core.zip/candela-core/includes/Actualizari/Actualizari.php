<?php
/**
 * Chain updates: every client site updates itself from one manifest we publish.
 *
 * The two Candela plugins and the Candela theme declare `Update URI:
 * https://researchmind.org/site-parohie/actualizari/` in their headers. WordPress then asks the
 * `update_plugins_researchmind.org` / `update_themes_researchmind.org` filters (WP 5.8 / 6.1) instead
 * of wordpress.org; we answer from a JSON manifest:
 *
 *   { "canale": { "stabil": { "candela-core": { "versiune": "0.3.0",
 *                                                "pachet": "https://…/candela-core-0.3.0.zip",
 *                                                "sha256": "…" }, … },
 *                 "test":   { … } } }
 *
 * - Channel: a site follows `stabil` unless the option `candela_canal` says `test` (demo and canary
 *   sites), so a release reaches one site first and every site only after it is promoted.
 * - Auto-updates are switched on for our components only; WordPress installs them in its twice-daily
 *   cron, with its own maintenance mode and plugin-error rollback.
 * - Every package is checked against the SHA-256 from the manifest before WordPress unpacks it.
 * - Data lives in options and posts, never in plugin files, so an update keeps every client setting.
 *
 * Manifest address: constant CANDELA_ACTUALIZARI_URL, else the default below.
 *
 * @package Candela\Core
 */

namespace Candela\Core\Actualizari;

use Candela\Core\Modul;

/**
 * Chain-update module.
 */
final class Actualizari implements Modul {

	public const MANIFEST  = 'https://researchmind.org/site-parohie/actualizari/manifest.json';
	public const GAZDA     = 'researchmind.org';
	public const TRANZIENT = 'candela_manifest';
	public const CANAL     = 'candela_canal';

	/** Plugin file => manifest slug. */
	public const PLUGINURI = array(
		'candela-core/candela-core.php'         => 'candela-core',
		'candela-parohia/candela-parohia.php'   => 'candela-parohia',
	);

	/** Theme stylesheet => manifest slug. */
	public const TEME = array( 'candela' => 'candela' );

	/**
	 * Hooks.
	 */
	public function register(): void {
		add_filter( 'update_plugins_' . self::GAZDA, array( $this, 'plugin' ), 10, 3 );
		add_filter( 'update_themes_' . self::GAZDA, array( $this, 'tema' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'automat_plugin' ), 10, 2 );
		add_filter( 'auto_update_theme', array( $this, 'automat_tema' ), 10, 2 );
		add_filter( 'upgrader_pre_download', array( $this, 'verifica_pachet' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( self::class, 'goleste' ) );
	}

	/**
	 * The channel this site follows.
	 */
	public static function canal(): string {
		return 'test' === get_option( self::CANAL ) ? 'test' : 'stabil';
	}

	/**
	 * Manifest entries for this site's channel, cached for six hours.
	 *
	 * @return array<string, array{versiune:string, pachet:string, sha256?:string}>
	 */
	public static function intrari(): array {
		$m = get_site_transient( self::TRANZIENT );
		if ( ! is_array( $m ) ) {
			$url = defined( 'CANDELA_ACTUALIZARI_URL' ) ? (string) constant( 'CANDELA_ACTUALIZARI_URL' ) : self::MANIFEST;
			$r   = wp_remote_get( $url, array( 'timeout' => 10 ) );
			$m   = array();
			if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
				$dec = json_decode( wp_remote_retrieve_body( $r ), true );
				$m   = is_array( $dec ) ? $dec : array();
			}
			// Cache failures briefly, successes for six hours.
			set_site_transient( self::TRANZIENT, $m, $m ? 6 * HOUR_IN_SECONDS : 15 * MINUTE_IN_SECONDS );
		}
		$canal = $m['canale'][ self::canal() ] ?? array();
		return is_array( $canal ) ? $canal : array();
	}

	/**
	 * Forgets the cached manifest (after an update, or on demand).
	 */
	public static function goleste(): void {
		delete_site_transient( self::TRANZIENT );
	}

	/**
	 * Builds the update answer for one slug, or false when there is nothing newer.
	 *
	 * @param string $slug     Manifest slug.
	 * @param string $versiune Installed version.
	 * @return array|false
	 */
	private static function raspuns( string $slug, string $versiune ) {
		$i = self::intrari()[ $slug ] ?? null;
		if ( ! is_array( $i ) || empty( $i['versiune'] ) || empty( $i['pachet'] ) ) {
			return false;
		}
		if ( ! version_compare( (string) $i['versiune'], $versiune, '>' ) ) {
			return false;
		}
		return array(
			'slug'    => $slug,
			'version' => (string) $i['versiune'],
			'package' => esc_url_raw( (string) $i['pachet'] ),
			'url'     => 'https://researchmind.org/site-parohie/',
		);
	}

	/**
	 * `update_plugins_{host}` filter.
	 *
	 * @param array|false $update      Previous answer.
	 * @param array       $plugin_data Plugin headers.
	 * @param string      $plugin_file Plugin file.
	 * @return array|false
	 */
	public function plugin( $update, $plugin_data, $plugin_file ) {
		$slug = self::PLUGINURI[ $plugin_file ] ?? null;
		if ( ! $slug ) {
			return $update;
		}
		$r = self::raspuns( $slug, (string) ( $plugin_data['Version'] ?? '0' ) );
		return $r ? $r + array( 'plugin' => $plugin_file, 'id' => $plugin_file ) : $update;
	}

	/**
	 * `update_themes_{host}` filter.
	 *
	 * @param array|false $update     Previous answer.
	 * @param array       $theme_data Theme headers.
	 * @param string      $stylesheet Theme directory.
	 * @return array|false
	 */
	public function tema( $update, $theme_data, $stylesheet ) {
		$slug = self::TEME[ $stylesheet ] ?? null;
		if ( ! $slug ) {
			return $update;
		}
		$r = self::raspuns( $slug, (string) ( $theme_data['Version'] ?? '0' ) );
		return $r ? array( 'theme' => $stylesheet ) + $r : $update;
	}

	/**
	 * Auto-update our plugins.
	 *
	 * @param bool|null $update Current decision.
	 * @param object    $item   Update item.
	 */
	public function automat_plugin( $update, $item ) {
		return isset( $item->plugin ) && isset( self::PLUGINURI[ $item->plugin ] ) ? true : $update;
	}

	/**
	 * Auto-update our theme.
	 *
	 * @param bool|null $update Current decision.
	 * @param object    $item   Update item.
	 */
	public function automat_tema( $update, $item ) {
		return isset( $item->theme ) && isset( self::TEME[ $item->theme ] ) ? true : $update;
	}

	/**
	 * Downloads our packages ourselves and checks their SHA-256 before WordPress unpacks them.
	 *
	 * @param false|string|\WP_Error $raspuns Previous result.
	 * @param string                 $pachet  Package URL.
	 * @return false|string|\WP_Error
	 */
	public function verifica_pachet( $raspuns, $pachet ) {
		if ( false !== $raspuns ) {
			return $raspuns;
		}
		$asteptat = '';
		foreach ( self::intrari() as $i ) {
			if ( is_array( $i ) && ( $i['pachet'] ?? '' ) === $pachet ) {
				$asteptat = strtolower( (string) ( $i['sha256'] ?? '' ) );
			}
		}
		if ( '' === $asteptat ) {
			return $raspuns; // Not ours: let WordPress handle it.
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$fisier = download_url( $pachet );
		if ( is_wp_error( $fisier ) ) {
			return $fisier;
		}
		if ( ! hash_equals( $asteptat, (string) hash_file( 'sha256', $fisier ) ) ) {
			wp_delete_file( $fisier );
			return new \WP_Error( 'candela_sha256', __( 'The update package does not match its checksum and was not installed.', 'candela-core' ) );
		}
		return $fisier;
	}
}
