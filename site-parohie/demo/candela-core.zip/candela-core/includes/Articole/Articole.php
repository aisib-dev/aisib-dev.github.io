<?php
/**
 * Articles: announcements and blog as regular posts in two categories (ADR 0003).
 *
 * - Creates the categories `anunturi` (short, practical notices) and `articole` (blog) on activation.
 * - The blog page (WordPress "posts page") hides announcements; they have their own archive.
 * - Block `candela/articole`: latest posts of a category, as cards or as a list.
 *
 * @package Candela\Core
 */

namespace Candela\Core\Articole;

use Candela\Core\Modul;

/**
 * Articles module.
 */
final class Articole implements Modul {

	public const ANUNTURI = 'anunturi';
	public const BLOG     = 'articole';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'bloc' ) );
		add_action( 'pre_get_posts', array( $this, 'blog_fara_anunturi' ) );
	}

	/**
	 * Creates the two categories if missing. Called on plugin activation.
	 */
	public static function categorii(): void {
		$cats = array(
			self::ANUNTURI => __( 'Announcements', 'candela-core' ),
			self::BLOG     => __( 'Articles', 'candela-core' ),
		);
		foreach ( $cats as $slug => $nume ) {
			if ( ! term_exists( $slug, 'category' ) ) {
				wp_insert_term( $nume, 'category', array( 'slug' => $slug ) );
			}
		}
	}

	/**
	 * The blog page lists articles, not announcements.
	 *
	 * @param \WP_Query $q Query.
	 */
	public function blog_fara_anunturi( \WP_Query $q ): void {
		if ( is_admin() || ! $q->is_main_query() || ! $q->is_home() ) {
			return;
		}
		/**
		 * Filters the category slugs hidden from the blog page.
		 *
		 * @since 0.1.0
		 * @param string[] $slugs Category slugs.
		 */
		$ascunse = (array) apply_filters( 'candela_blog_exclude', array( self::ANUNTURI ) );
		$ids     = array();
		foreach ( $ascunse as $slug ) {
			$t = get_category_by_slug( $slug );
			if ( $t ) {
				$ids[] = (int) $t->term_id;
			}
		}
		if ( $ids ) {
			$q->set( 'category__not_in', $ids );
		}
	}

	/**
	 * Registers the block.
	 */
	public function bloc(): void {
		register_block_type( CANDELA_CORE_DIR . '/blocks/articole' );
	}

	/**
	 * Posts for the block.
	 *
	 * @param string $categorie Category slug ('' = all).
	 * @param int    $numar     How many.
	 * @return \WP_Post[]
	 */
	public static function ultimele( string $categorie, int $numar ): array {
		$args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, min( 12, $numar ) ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		if ( '' !== $categorie ) {
			$args['category_name'] = $categorie;
		}
		return get_posts( $args );
	}
}
