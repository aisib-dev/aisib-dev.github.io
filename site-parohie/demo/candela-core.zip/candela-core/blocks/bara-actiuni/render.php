<?php
/**
 * Server render of candela/bara-actiuni.
 *
 * @package Candela\Core
 */

defined( 'ABSPATH' ) || exit;

use Candela\Core\Organizatie\Organizatie;

$candela_icon = array(
	'telefon' => '<path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/>',
	'ceas'    => '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 10.4 3.3 2-.9 1.5L11 13V6h2z"/>',
	'lumanare' => '<path d="M12 2c1.6 1.8 2.4 3.3 2.4 4.5A2.4 2.4 0 0 1 12 9a2.4 2.4 0 0 1-2.4-2.5C9.6 5.3 10.4 3.8 12 2zM10 10h4v10h3v2H7v-2h3z"/>',
);

$candela_actiuni = array();
$candela_tel     = Organizatie::get( 'telefon' );
if ( $candela_tel ) {
	$candela_actiuni[] = array(
		'eticheta' => __( 'Call', 'candela-core' ),
		'url'      => 'tel:' . preg_replace( '/[^0-9+]/', '', $candela_tel ),
		'icon'     => 'telefon',
	);
}

/**
 * Filters the quick actions shown at the bottom of small screens (max. 4 are shown).
 *
 * @since 0.1.0
 * @param array $actiuni List of [eticheta, url, icon ('telefon'|'ceas'|'lumanare')].
 */
$candela_actiuni = array_slice( (array) apply_filters( 'candela_bara_actiuni', $candela_actiuni ), 0, 4 );
if ( ! $candela_actiuni ) {
	return;
}
?>
<nav <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-bara' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?> aria-label="<?php esc_attr_e( 'Quick actions', 'candela-core' ); ?>">
	<?php foreach ( $candela_actiuni as $candela_a ) : ?>
		<a class="candela-bara__link" href="<?php echo esc_url( $candela_a['url'], array( 'http', 'https', 'tel', 'mailto' ) ); ?>">
			<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" fill="currentColor"><?php echo $candela_icon[ $candela_a['icon'] ?? 'ceas' ] ?? $candela_icon['ceas']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG from this file. ?></svg>
			<span><?php echo esc_html( $candela_a['eticheta'] ); ?></span>
		</a>
	<?php endforeach; ?>
</nav>
