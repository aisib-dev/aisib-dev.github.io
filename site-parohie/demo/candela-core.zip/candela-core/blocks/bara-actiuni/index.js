/**
 * Editor side of candela/bara-actiuni. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	wp.blocks.registerBlockType( 'candela/bara-actiuni', {
		edit: function ( props ) {
			return wp.element.createElement( 'div', wp.blockEditor.useBlockProps(), wp.element.createElement( wp.serverSideRender, { block: 'candela/bara-actiuni', attributes: props.attributes } ) );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
