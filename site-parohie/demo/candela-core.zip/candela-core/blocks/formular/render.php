<?php
/**
 * Server render of candela/formular.
 *
 * @package Candela\Core
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

use Candela\Core\Formulare\Formulare;

$candela_tip    = sanitize_key( $attributes['tip'] ?? 'contact' );
$candela_tipuri = Formulare::tipuri();
if ( ! isset( $candela_tipuri[ $candela_tip ] ) ) {
	return;
}
$candela_def = $candela_tipuri[ $candela_tip ];
$candela_id  = 'candela-formular-' . $candela_tip;
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display-only status flags.
$candela_ok  = isset( $_GET['candela_trimis'] ) && sanitize_key( wp_unslash( $_GET['candela_trimis'] ) ) === $candela_tip;
$candela_err = isset( $_GET['candela_eroare'] ) ? sanitize_key( wp_unslash( $_GET['candela_eroare'] ) ) : '';
// phpcs:enable
$candela_mesaje_eroare = array(
	'acord'  => __( 'Please tick the consent box; without it we cannot keep your request.', 'candela-core' ),
	'camp'   => __( 'Please fill in all the required fields.', 'candela-core' ),
	'timp'   => __( 'The form was sent too quickly or is too old. Please reload the page and try again.', 'candela-core' ),
	'limita' => __( 'Too many requests from this connection. Please try again in an hour.', 'candela-core' ),
);
$candela_zile = Formulare::setari()['retentie_zile'];
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-formular' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?> id="<?php echo esc_attr( $candela_id ); ?>">
	<?php if ( $candela_ok ) : ?>
		<div class="candela-formular__ok" role="status">
			<p><?php echo esc_html( $candela_def['multumire'] ); ?></p>
		</div>
	<?php else : ?>
		<?php if ( isset( $candela_mesaje_eroare[ $candela_err ] ) ) : ?>
			<div class="candela-formular__eroare" role="alert"><p><?php echo esc_html( $candela_mesaje_eroare[ $candela_err ] ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="candela-formular__form">
			<input type="hidden" name="action" value="<?php echo esc_attr( Formulare::ACTIUNE ); ?>">
			<input type="hidden" name="candela_tip" value="<?php echo esc_attr( $candela_tip ); ?>">
			<input type="hidden" name="candela_t" value="<?php echo esc_attr( Formulare::jeton() ); ?>">
			<p class="candela-formular__capcana" aria-hidden="true">
				<label><?php esc_html_e( 'Leave this field empty', 'candela-core' ); ?>
					<input type="text" name="candela_site" value="" tabindex="-1" autocomplete="off">
				</label>
			</p>
			<?php foreach ( $candela_def['campuri'] as $candela_c ) : ?>
				<?php
				$candela_n   = 'candela_' . $candela_c['nume'];
				$candela_fid = $candela_id . '-' . $candela_c['nume'];
				$candela_req = ! empty( $candela_c['obligatoriu'] );
				$candela_t   = $candela_c['tip'] ?? 'text';
				?>
				<div class="candela-formular__camp candela-formular__camp--<?php echo esc_attr( $candela_t ); ?>">
					<?php if ( 'radio' === $candela_t ) : ?>
						<fieldset>
							<legend><?php echo esc_html( $candela_c['eticheta'] ); ?><?php echo $candela_req ? ' <span aria-hidden="true">*</span>' : ''; ?></legend>
							<?php $candela_prima = true; foreach ( (array) $candela_c['optiuni'] as $candela_k => $candela_o ) : ?>
								<label class="candela-formular__optiune">
									<input type="radio" name="<?php echo esc_attr( $candela_n ); ?>" value="<?php echo esc_attr( (string) $candela_k ); ?>" <?php checked( $candela_prima ); $candela_prima = false; ?> <?php echo $candela_req ? 'required' : ''; ?>>
									<span><?php echo esc_html( $candela_o ); ?></span>
								</label>
							<?php endforeach; ?>
						</fieldset>
					<?php else : ?>
						<label for="<?php echo esc_attr( $candela_fid ); ?>"><?php echo esc_html( $candela_c['eticheta'] ); ?><?php echo $candela_req ? ' <span aria-hidden="true">*</span>' : ''; ?></label>
						<?php if ( 'textarea' === $candela_t ) : ?>
							<textarea id="<?php echo esc_attr( $candela_fid ); ?>" name="<?php echo esc_attr( $candela_n ); ?>" rows="<?php echo (int) ( $candela_c['randuri'] ?? 5 ); ?>" <?php echo $candela_req ? 'required' : ''; ?>></textarea>
						<?php elseif ( 'select' === $candela_t ) : ?>
							<select id="<?php echo esc_attr( $candela_fid ); ?>" name="<?php echo esc_attr( $candela_n ); ?>" <?php echo $candela_req ? 'required' : ''; ?>>
								<option value=""><?php esc_html_e( 'Choose…', 'candela-core' ); ?></option>
								<?php foreach ( (array) $candela_c['optiuni'] as $candela_k => $candela_o ) : ?>
									<option value="<?php echo esc_attr( (string) $candela_k ); ?>"><?php echo esc_html( $candela_o ); ?></option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<input id="<?php echo esc_attr( $candela_fid ); ?>" type="<?php echo esc_attr( $candela_t ); ?>" name="<?php echo esc_attr( $candela_n ); ?>" <?php echo 'date' === $candela_t ? 'min="' . esc_attr( current_datetime()->format( 'Y-m-d' ) ) . '"' : ''; ?> <?php echo $candela_req ? 'required' : ''; ?> autocomplete="<?php echo esc_attr( in_array( $candela_t, array( 'email', 'tel' ), true ) ? $candela_t : ( 'nume' === $candela_c['nume'] ? 'name' : 'off' ) ); ?>">
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( ! empty( $candela_c['ajutor'] ) ) : ?>
						<p class="candela-formular__ajutor"><?php echo esc_html( $candela_c['ajutor'] ); ?></p>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
			<div class="candela-formular__acord">
				<label>
					<input type="checkbox" name="candela_acord" value="1" required>
					<span><?php echo esc_html( $candela_def['consimtamant'] ); ?></span>
				</label>
				<p class="candela-formular__ajutor">
					<?php
					/* translators: %d: number of days. */
					echo esc_html( sprintf( _n( 'Kept for %d day, then deleted automatically. Never shared with anyone.', 'Kept for %d days, then deleted automatically. Never shared with anyone.', $candela_zile, 'candela-core' ), $candela_zile ) );
					?>
				</p>
			</div>
			<p class="candela-formular__trimite">
				<button type="submit" class="wp-element-button"><?php echo esc_html( $candela_def['buton'] ); ?></button>
			</p>
		</form>
	<?php endif; ?>
</div>
