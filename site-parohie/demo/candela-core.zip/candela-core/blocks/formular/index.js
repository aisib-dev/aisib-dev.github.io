/**
 * Editor side of candela/formular. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;

	wp.blocks.registerBlockType( 'candela/formular', {
		edit: function ( props ) {
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				el(
					wp.blockEditor.InspectorControls,
					null,
					el(
						wp.components.PanelBody,
						{ title: __( 'Settings', 'candela-core' ) },
						el( wp.components.TextControl, {
							label: __( 'Form type (contact, pomelnic, programare)', 'candela-core' ),
							value: props.attributes.tip,
							onChange: function ( v ) {
								props.setAttributes( { tip: v } );
							},
						} )
					)
				),
				el( wp.serverSideRender, { block: 'candela/formular', attributes: props.attributes } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
