/* Two-click map: the OpenStreetMap iframe is created only after the visitor presses the button. */
document.addEventListener( 'click', function ( e ) {
	var b = e.target.closest && e.target.closest( '.candela-harta__arata' );
	if ( ! b ) {
		return;
	}
	var cadru = b.closest( '.candela-harta__cadru' );
	var f = document.createElement( 'iframe' );
	f.src = cadru.getAttribute( 'data-src' );
	f.title = cadru.getAttribute( 'data-titlu' );
	f.width = '100%';
	f.height = '100%';
	f.style.cssText = 'display:block;width:100%;height:100%;border:0';
	f.loading = 'lazy';
	f.referrerPolicy = 'no-referrer';
	cadru.innerHTML = '';
	cadru.appendChild( f );
} );
