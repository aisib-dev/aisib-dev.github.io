<?php
/**
 * Server render of candela/harta. Two-click map: nothing is requested from OpenStreetMap until the
 * visitor presses the button (privacy by default).
 *
 * @package Candela\Core
 */

defined( 'ABSPATH' ) || exit;

use Candela\Core\Organizatie\Organizatie;

$candela_lat = (float) str_replace( ',', '.', Organizatie::get( 'lat' ) );
$candela_lng = (float) str_replace( ',', '.', Organizatie::get( 'lng' ) );
$candela_adr = Organizatie::get( 'adresa' );
$candela_are = ( 0.0 !== $candela_lat || 0.0 !== $candela_lng ) && abs( $candela_lat ) <= 90 && abs( $candela_lng ) <= 180;
if ( ! $candela_are && '' === $candela_adr ) {
	return;
}
$candela_q    = $candela_are ? $candela_lat . ',' . $candela_lng : $candela_adr;
$candela_d    = 0.004;
$candela_src  = $candela_are ? sprintf( 'https://www.openstreetmap.org/export/embed.html?bbox=%1$F,%2$F,%3$F,%4$F&layer=mapnik&marker=%5$F,%6$F', $candela_lng - $candela_d, $candela_lat - $candela_d / 2, $candela_lng + $candela_d, $candela_lat + $candela_d / 2, $candela_lat, $candela_lng ) : '';
$candela_osm  = $candela_are ? sprintf( 'https://www.openstreetmap.org/?mlat=%1$F&mlon=%2$F#map=17/%1$F/%2$F', $candela_lat, $candela_lng ) : 'https://www.openstreetmap.org/search?query=' . rawurlencode( $candela_adr );
$candela_ggl  = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $candela_q );
$candela_apl  = 'https://maps.apple.com/?q=' . rawurlencode( $candela_are ? Organizatie::get( 'nume' ) : $candela_adr ) . ( $candela_are ? '&ll=' . $candela_q : '' );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-harta' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>
	<?php if ( $candela_src ) : ?>
		<div class="candela-harta__cadru" data-src="<?php echo esc_url( $candela_src ); ?>" data-titlu="<?php esc_attr_e( 'Map', 'candela-core' ); ?>">
			<div class="candela-harta__invitatie">
				<p><?php esc_html_e( 'The map is loaded from OpenStreetMap only if you ask for it.', 'candela-core' ); ?></p>
				<button type="button" class="wp-element-button candela-harta__arata"><?php esc_html_e( 'Show the map', 'candela-core' ); ?></button>
			</div>
		</div>
	<?php endif; ?>
	<p class="candela-harta__linkuri">
		<?php if ( $candela_adr ) : ?><span class="candela-harta__adresa"><?php echo esc_html( $candela_adr ); ?></span><?php endif; ?>
		<a href="<?php echo esc_url( $candela_ggl ); ?>" rel="noopener" target="_blank">Google Maps</a>
		<a href="<?php echo esc_url( $candela_apl ); ?>" rel="noopener" target="_blank">Apple Maps</a>
		<a href="<?php echo esc_url( $candela_osm ); ?>" rel="noopener" target="_blank">OpenStreetMap</a>
	</p>
</div>
