/**
 * Editor side of candela/harta. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	wp.blocks.registerBlockType( 'candela/harta', {
		edit: function ( props ) {
			return wp.element.createElement( 'div', wp.blockEditor.useBlockProps(), wp.element.createElement( wp.serverSideRender, { block: 'candela/harta', attributes: props.attributes } ) );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
