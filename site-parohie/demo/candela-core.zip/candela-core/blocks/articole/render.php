<?php
/**
 * Server render of candela/articole.
 *
 * @package Candela\Core
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

$candela_cat    = sanitize_title( (string) ( $attributes['categorie'] ?? '' ) );
$candela_aspect = 'lista' === ( $attributes['aspect'] ?? '' ) ? 'lista' : 'carduri';
$candela_posts  = Candela\Core\Articole\Articole::ultimele( $candela_cat, (int) ( $attributes['numar'] ?? 3 ) );
$candela_term   = $candela_cat ? get_category_by_slug( $candela_cat ) : null;

if ( Candela\Core\Articole\Articole::BLOG === $candela_cat && get_option( 'page_for_posts' ) ) {
	$candela_toate = get_permalink( (int) get_option( 'page_for_posts' ) );
} elseif ( $candela_term ) {
	$candela_toate = get_category_link( $candela_term );
} else {
	$candela_toate = '';
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-articole candela-articole--' . $candela_aspect ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>
	<?php if ( ! $candela_posts ) : ?>
		<p class="candela-articole__gol"><?php esc_html_e( 'Nothing published yet.', 'candela-core' ); ?></p>
	<?php else : ?>
		<div class="candela-articole__grila">
			<?php foreach ( $candela_posts as $candela_p ) : ?>
				<article class="candela-articol">
					<?php if ( 'carduri' === $candela_aspect ) : ?>
						<a class="candela-articol__imagine" href="<?php echo esc_url( get_permalink( $candela_p ) ); ?>" tabindex="-1" aria-hidden="true">
							<?php if ( has_post_thumbnail( $candela_p ) ) : ?>
								<?php echo get_the_post_thumbnail( $candela_p, 'medium_large', array( 'loading' => 'lazy' ) ); ?>
							<?php else : ?>
								<span class="candela-articol__fara-imagine">&#10013;</span>
							<?php endif; ?>
						</a>
					<?php endif; ?>
					<div class="candela-articol__text">
						<p class="candela-articol__data"><?php echo esc_html( get_the_date( '', $candela_p ) ); ?></p>
						<h3 class="candela-articol__titlu"><a href="<?php echo esc_url( get_permalink( $candela_p ) ); ?>"><?php echo esc_html( get_the_title( $candela_p ) ); ?></a></h3>
						<p class="candela-articol__rezumat"><?php echo esc_html( wp_trim_words( get_the_excerpt( $candela_p ), 'carduri' === $candela_aspect ? 22 : 32 ) ); ?></p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
		<?php if ( ! empty( $attributes['linkToate'] ) && $candela_toate ) : ?>
			<p class="candela-articole__toate"><a href="<?php echo esc_url( $candela_toate ); ?>">
				<?php echo esc_html( Candela\Core\Articole\Articole::ANUNTURI === $candela_cat ? __( 'All announcements', 'candela-core' ) : __( 'All articles', 'candela-core' ) ); ?> &rarr;
			</a></p>
		<?php endif; ?>
	<?php endif; ?>
</div>
