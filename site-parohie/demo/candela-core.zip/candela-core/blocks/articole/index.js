/**
 * Editor side of candela/articole. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var c = wp.components;

	wp.blocks.registerBlockType( 'candela/articole', {
		edit: function ( props ) {
			var a = props.attributes;
			var set = props.setAttributes;
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				el(
					wp.blockEditor.InspectorControls,
					null,
					el(
						c.PanelBody,
						{ title: __( 'Settings', 'candela-core' ) },
						el( c.SelectControl, {
							label: __( 'Category', 'candela-core' ),
							value: a.categorie,
							options: [
								{ label: __( 'Articles (blog)', 'candela-core' ), value: 'articole' },
								{ label: __( 'Announcements', 'candela-core' ), value: 'anunturi' },
								{ label: __( 'All posts', 'candela-core' ), value: '' },
							],
							onChange: function ( v ) { set( { categorie: v } ); },
						} ),
						el( c.SelectControl, {
							label: __( 'Layout', 'candela-core' ),
							value: a.aspect,
							options: [
								{ label: __( 'Cards with image', 'candela-core' ), value: 'carduri' },
								{ label: __( 'List', 'candela-core' ), value: 'lista' },
							],
							onChange: function ( v ) { set( { aspect: v } ); },
						} ),
						el( c.RangeControl, {
							label: __( 'Number of posts', 'candela-core' ),
							min: 1,
							max: 12,
							value: a.numar,
							onChange: function ( v ) { set( { numar: v } ); },
						} ),
						el( c.ToggleControl, {
							label: __( 'Link to all posts', 'candela-core' ),
							checked: !! a.linkToate,
							onChange: function ( v ) { set( { linkToate: v } ); },
						} )
					)
				),
				el( wp.serverSideRender, { block: 'candela/articole', attributes: a } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
