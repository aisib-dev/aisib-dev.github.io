<?php
/**
 * Server render of candela/sprijin.
 *
 * @package Candela\Core
 */

defined( 'ABSPATH' ) || exit;

use Candela\Core\Organizatie\Organizatie;

$candela_iban    = Organizatie::get( 'iban' );
$candela_titular = Organizatie::get( 'titular_cont' ) ? Organizatie::get( 'titular_cont' ) : Organizatie::get( 'nume' );
$candela_link    = Organizatie::get( 'link_donatie' );
$candela_cif     = Organizatie::get( 'cif' );
$candela_ro      = 'RO' === strtoupper( Organizatie::get( 'tara' ) ) || '' !== $candela_cif;
$candela_carduri = array();
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-sprijin' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>
	<?php if ( $candela_iban ) : ?>
		<section class="candela-sprijin__card">
			<h3><?php esc_html_e( 'Bank transfer', 'candela-core' ); ?></h3>
			<dl>
				<dt><?php esc_html_e( 'Account holder', 'candela-core' ); ?></dt>
				<dd><?php echo esc_html( $candela_titular ); ?></dd>
				<dt><?php esc_html_e( 'IBAN', 'candela-core' ); ?></dt>
				<dd class="candela-sprijin__iban">
					<code><?php echo esc_html( trim( chunk_split( preg_replace( '/\s+/', '', $candela_iban ), 4, ' ' ) ) ); ?></code>
					<button type="button" class="candela-sprijin__copiaza" data-text="<?php echo esc_attr( preg_replace( '/\s+/', '', $candela_iban ) ); ?>" data-ok="<?php esc_attr_e( 'Copied', 'candela-core' ); ?>"><?php esc_html_e( 'Copy', 'candela-core' ); ?></button>
				</dd>
				<dt><?php esc_html_e( 'Payment reference', 'candela-core' ); ?></dt>
				<dd><?php esc_html_e( 'Donation', 'candela-core' ); ?></dd>
			</dl>
		</section>
	<?php endif; ?>
	<?php if ( $candela_link ) : ?>
		<section class="candela-sprijin__card">
			<h3><?php esc_html_e( 'Online', 'candela-core' ); ?></h3>
			<p><?php esc_html_e( 'By card, through a secure payment page.', 'candela-core' ); ?></p>
			<p><a class="wp-element-button" href="<?php echo esc_url( $candela_link ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Donate online', 'candela-core' ); ?></a></p>
		</section>
	<?php endif; ?>
	<?php if ( $candela_ro && $candela_cif ) : ?>
		<section class="candela-sprijin__card">
			<h3><?php esc_html_e( 'Form 230 (Romania)', 'candela-core' ); ?></h3>
			<p><?php esc_html_e( 'If you pay income tax in Romania (for example on a salary), you can direct up to 3.5% of it to the parish, at no cost to you, with Form 230.', 'candela-core' ); ?></p>
			<dl>
				<dt><?php esc_html_e( 'Tax identification number (CIF)', 'candela-core' ); ?></dt>
				<dd class="candela-sprijin__iban">
					<code><?php echo esc_html( $candela_cif ); ?></code>
					<button type="button" class="candela-sprijin__copiaza" data-text="<?php echo esc_attr( $candela_cif ); ?>" data-ok="<?php esc_attr_e( 'Copied', 'candela-core' ); ?>"><?php esc_html_e( 'Copy', 'candela-core' ); ?></button>
				</dd>
			</dl>
			<p class="candela-sprijin__nota"><?php esc_html_e( 'The form is filed with the tax office (ANAF) each year. Ask the priest if you would like help filling it in.', 'candela-core' ); ?></p>
		</section>
	<?php endif; ?>
	<?php if ( ! $candela_iban && ! $candela_link && ! ( $candela_ro && $candela_cif ) ) : ?>
		<p><?php esc_html_e( 'Please ask the priest how you can help the parish.', 'candela-core' ); ?></p>
	<?php endif; ?>
</div>
