/**
 * Editor side of candela/sprijin. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	wp.blocks.registerBlockType( 'candela/sprijin', {
		edit: function ( props ) {
			return wp.element.createElement( 'div', wp.blockEditor.useBlockProps(), wp.element.createElement( wp.serverSideRender, { block: 'candela/sprijin', attributes: props.attributes } ) );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
