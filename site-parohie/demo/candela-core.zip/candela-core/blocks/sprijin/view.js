/* Copy buttons for IBAN and CIF. Works without a build step; degrades to plain text without JS. */
document.addEventListener( 'click', function ( e ) {
	var b = e.target.closest && e.target.closest( '.candela-sprijin__copiaza' );
	if ( ! b || ! navigator.clipboard ) {
		return;
	}
	navigator.clipboard.writeText( b.getAttribute( 'data-text' ) ).then( function () {
		var vechi = b.textContent;
		b.textContent = b.getAttribute( 'data-ok' );
		setTimeout( function () {
			b.textContent = vechi;
		}, 1800 );
	} );
} );
