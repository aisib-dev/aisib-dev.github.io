<?php
/**
 * Server render of candela/contact: tap-to-call phone, mailto e-mail, address with optional map link.
 *
 * @package Candela\Core
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

use Candela\Core\Organizatie\Organizatie;

$candela_tel   = Organizatie::get( 'telefon' );
$candela_mail  = Organizatie::get( 'email' );
$candela_adr   = Organizatie::get( 'adresa' );
$candela_harta = Organizatie::get( 'harta' );
$candela_preot = Organizatie::get( 'preot_nume' );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-contact' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>
	<?php if ( ! empty( $attributes['arataNume'] ) && Organizatie::get( 'nume' ) ) : ?>
		<p class="candela-contact__nume"><?php echo esc_html( Organizatie::get( 'nume' ) ); ?></p>
	<?php endif; ?>
	<?php if ( $candela_adr ) : ?>
		<p class="candela-contact__adresa">
			<?php if ( $candela_harta ) : ?>
				<a href="<?php echo esc_url( $candela_harta ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $candela_adr ); ?></a>
			<?php else : ?>
				<?php echo esc_html( $candela_adr ); ?>
			<?php endif; ?>
		</p>
	<?php endif; ?>
	<?php if ( $candela_preot ) : ?>
		<p class="candela-contact__preot"><?php echo esc_html( $candela_preot ); ?></p>
	<?php endif; ?>
	<?php if ( $candela_tel ) : ?>
		<p class="candela-contact__telefon"><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $candela_tel ) ); ?>"><?php echo esc_html( $candela_tel ); ?></a></p>
	<?php endif; ?>
	<?php if ( $candela_mail ) : ?>
		<p class="candela-contact__email"><a href="mailto:<?php echo esc_attr( antispambot( $candela_mail ) ); ?>"><?php echo esc_html( antispambot( $candela_mail ) ); ?></a></p>
	<?php endif; ?>
</div>
