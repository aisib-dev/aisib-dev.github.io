/**
 * Editor side of candela/contact. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	wp.blocks.registerBlockType( 'candela/contact', {
		edit: function ( props ) {
			return wp.element.createElement( 'div', wp.blockEditor.useBlockProps(), wp.element.createElement( wp.serverSideRender, { block: 'candela/contact', attributes: props.attributes } ) );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
