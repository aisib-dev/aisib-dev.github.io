<?php
/**
 * Plugin Name:       Candela Core
 * Description:       Shared core of the Candela website kit: organisation data, forms engine, simplified dashboard, donations, client profile import.
 * Version:           0.3.3
 * Update URI:        https://researchmind.org/site-parohie/actualizari/
 * Requires at least: 6.9
 * Requires PHP:      8.1
 * Author:            Candela Parohiei
 * License:           GPL-2.0-or-later
 * Text Domain:       candela-core
 * Domain Path:       /languages
 *
 * @package Candela\Core
 */

defined( 'ABSPATH' ) || exit;

define( 'CANDELA_CORE_VERSION', '0.3.3' );
define( 'CANDELA_CORE_DIR', __DIR__ );

/*
 * PSR-4 style autoloader: Candela\Core\Foo\Bar -> includes/Foo/Bar.php.
 * Kept dependency-free so the plugin installs from a plain zip, without Composer.
 */
spl_autoload_register(
	static function ( string $clasa ): void {
		$prefix = 'Candela\\Core\\';
		if ( 0 !== strpos( $clasa, $prefix ) ) {
			return;
		}
		$fisier = __DIR__ . '/includes/' . str_replace( '\\', '/', substr( $clasa, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $fisier ) ) {
			require $fisier;
		}
	}
);

add_action( 'plugins_loaded', array( Candela\Core\Plugin::class, 'boot' ), 5 );

register_activation_hook( __FILE__, array( Candela\Core\Plugin::class, 'activare' ) );
register_deactivation_hook( __FILE__, array( Candela\Core\Plugin::class, 'dezactivare' ) );
