<?php
/**
 * Candela theme. Presentation only: the only code here loads the stylesheet.
 *
 * @package Candela\Theme
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		$tema = wp_get_theme();
		wp_enqueue_style( 'candela', get_stylesheet_uri(), array(), $tema->get( 'Version' ) );
	}
);

add_action(
	'after_setup_theme',
	static function (): void {
		add_editor_style( 'style.css' );
		load_theme_textdomain( 'candela', get_template_directory() . '/languages' );
	}
);
