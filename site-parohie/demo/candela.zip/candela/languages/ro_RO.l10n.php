<?php
return array(
	'domain' => 'candela',
	'plural-forms' => 'nplurals=3; plural=(n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2);',
	'language' => 'ro_RO',
	'messages' => array(
		'Services this week' => 'Slujbele din această săptămână',
		'Announcements' => 'Anunțuri',
		'For you' => 'Pentru dumneavoastră',
		'Send a pomelnic' => 'Trimiteți un pomelnic',
		'Write the names of the living and the departed; the priest commemorates them at the Divine Liturgy.' => 'Scrieți numele celor vii și ale celor adormiți, iar preotul îi pomenește la Sfânta Liturghie.',
		'Pomelnic online' => 'Pomelnic online',
		'Sacraments and services' => 'Sfinte Taine și slujbe',
		'Baptism, wedding, confession, house blessing, memorial service: choose a date and we will confirm it.' => 'Botez, cununie, spovedanie, sfeștanie, parastas: alegeți o dată, iar noi o confirmăm.',
		'Book a service' => 'Programați o slujbă',
		'Support the parish' => 'Sprijiniți parohia',
		'The church lives from the gifts of its faithful. Thank you for every help.' => 'Biserica trăiește din darurile credincioșilor ei. Vă mulțumim pentru orice ajutor.',
		'How you can help' => 'Cum puteți ajuta',
		'From the parish blog' => 'Din blogul parohiei',
		'Nothing published yet.' => 'Încă nu s-a publicat nimic.',
		'Words of help, catechesis and news from the life of the parish.' => 'Cuvinte de folos, cateheze și vești din viața parohiei.',
		'Service schedule' => 'Programul slujbelor',
	),
);
