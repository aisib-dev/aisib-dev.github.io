<?php
/**
 * Title: Home page of a parish
 * Slug: candela/acasa
 * Categories: featured
 * Keywords: parish, home, acasa
 * Description: Hero with the parish name and feast countdown, weekly services, announcements, quick actions, contact.
 * Viewport Width: 1280
 *
 * @package Candela\Theme
 */

?>
<!-- wp:group {"align":"full","className":"candela-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"backgroundColor":"primary","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-hero has-base-color has-primary-background-color has-text-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"textAlign":"center","level":1,"metadata":{"bindings":{"content":{"source":"candela/organizatie","args":{"key":"nume"}}}}} -->
<h1 class="wp-block-heading has-text-align-center"></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"candela-hram","fontSize":"large","metadata":{"bindings":{"content":{"source":"candela/organizatie","args":{"key":"hram"}}}}} -->
<p class="has-text-align-center candela-hram has-large-font-size"></p>
<!-- /wp:paragraph -->

<!-- wp:candela/numaratoare-praznic {"url":"#program","fontSize":"medium"} /-->

<!-- wp:buttons {"className":"candela-hero__butoane","layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons candela-hero__butoane"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#program"><?php echo esc_html__( 'Service schedule', 'candela' ); ?></a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/pomelnic/"><?php echo esc_html__( 'Send a pomelnic', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"program","align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div id="program" class="wp-block-group alignfull candela-sectiune has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Services this week', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/program-slujbe {"zile":7,"align":"wide"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune candela-anunturi","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune candela-anunturi" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Announcements', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/articole {"categorie":"anunturi","aspect":"lista","numar":3} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'From the parish blog', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/articole {"categorie":"articole","aspect":"carduri","numar":3,"align":"wide"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'For you', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"candela-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group candela-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html__( 'Send a pomelnic', 'candela' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Write the names of the living and the departed; the priest commemorates them at the Divine Liturgy.', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/pomelnic/"><?php echo esc_html__( 'Pomelnic online', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"candela-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group candela-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html__( 'Sacraments and services', 'candela' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Baptism, wedding, confession, house blessing, memorial service: choose a date and we will confirm it.', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/slujbe/"><?php echo esc_html__( 'Book a service', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"candela-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group candela-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html__( 'Support the parish', 'candela' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'The church lives from the gifts of its faithful. Thank you for every help.', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/sprijin/"><?php echo esc_html__( 'How you can help', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
