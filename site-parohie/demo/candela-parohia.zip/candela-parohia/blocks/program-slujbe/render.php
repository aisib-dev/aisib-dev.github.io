<?php
/**
 * Server render of candela/program-slujbe.
 * Views: `zile` (cards for the next N days), `luna` (month calendar with previous/next month),
 * `lista` (compact list for N days, with a print button: for the church notice board).
 *
 * @package Candela\Parohia
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

use Candela\Parohia\Slujbe\Slujbe;

$candela_vedere = in_array( $attributes['vedere'] ?? 'zile', array( 'zile', 'luna', 'lista' ), true ) ? $attributes['vedere'] : 'zile';
$candela_utc    = new DateTimeZone( 'UTC' );
$candela_azi    = current_datetime()->format( 'Y-m-d' );
$candela_mare   = static function ( string $s ): string {
	return mb_strtoupper( mb_substr( $s, 0, 1 ) ) . mb_substr( $s, 1 );
};
$candela_zi_txt = static function ( string $data, string $format ) use ( $candela_utc, $candela_mare ): string {
	return $candela_mare( wp_date( $format, ( new DateTimeImmutable( $data, $candela_utc ) )->getTimestamp(), $candela_utc ) );
};
$candela_rand_html = static function ( array $s ): string {
	$h  = '<li class="candela-program__slujba candela-program__slujba--' . esc_attr( $s['sursa'] ) . ' candela-program__slujba--' . esc_attr( $s['categorie'] ) . '">';
	$h .= '<span class="candela-program__ora">' . esc_html( $s['ora'] ) . '</span>';
	$h .= '<span class="candela-program__nume">' . esc_html( $s['slujba'] );
	if ( '' !== $s['nota'] ) {
		$h .= '<span class="candela-program__nota">' . esc_html( $s['nota'] ) . '</span>';
	}
	if ( '' !== $s['loc'] ) {
		$h .= '<span class="candela-program__loc">' . esc_html( $s['loc'] ) . '</span>';
	}
	return $h . '</span></li>';
};

if ( 'luna' === $candela_vedere ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- navigation only.
	$candela_cerut = isset( $_GET['candela_luna'] ) ? sanitize_text_field( wp_unslash( $_GET['candela_luna'] ) ) : '';
	$candela_luna  = preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $candela_cerut ) ? $candela_cerut : current_datetime()->format( 'Y-m' );
	$candela_prima = new DateTimeImmutable( $candela_luna . '-01', $candela_utc );
	$candela_nr    = (int) $candela_prima->format( 't' );
	$candela_rand  = Slujbe::urmatoarele( $candela_nr, $candela_prima );
} else {
	$candela_zile = max( 1, min( 62, (int) ( $attributes['zile'] ?? 7 ) ) );
	$candela_rand = Slujbe::urmatoarele( $candela_zile );
}

$candela_grupe = array();
foreach ( $candela_rand as $candela_r ) {
	$candela_grupe[ $candela_r['data'] ][] = $candela_r;
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-program candela-program--' . $candela_vedere ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>

<?php if ( 'luna' === $candela_vedere ) : ?>
	<?php
	$candela_link = static fn( DateTimeImmutable $d ) => add_query_arg( 'candela_luna', $d->format( 'Y-m' ) ) . '#program-luna';
	$candela_gol  = (int) $candela_prima->format( 'N' ) - 1; // Empty cells before the 1st (weeks start on Monday).
	?>
	<div class="candela-luna" id="program-luna">
		<div class="candela-luna__antet">
			<a class="candela-luna__nav" href="<?php echo esc_url( $candela_link( $candela_prima->modify( '-1 month' ) ) ); ?>" aria-label="<?php esc_attr_e( 'Previous month', 'candela-parohia' ); ?>">&larr;</a>
			<h3 class="candela-luna__titlu"><?php echo esc_html( $candela_zi_txt( $candela_prima->format( 'Y-m-d' ), 'F Y' ) ); ?></h3>
			<a class="candela-luna__nav" href="<?php echo esc_url( $candela_link( $candela_prima->modify( '+1 month' ) ) ); ?>" aria-label="<?php esc_attr_e( 'Next month', 'candela-parohia' ); ?>">&rarr;</a>
		</div>
		<div class="candela-luna__grila" role="list">
			<?php foreach ( array( __( 'Mon', 'candela-parohia' ), __( 'Tue', 'candela-parohia' ), __( 'Wed', 'candela-parohia' ), __( 'Thu', 'candela-parohia' ), __( 'Fri', 'candela-parohia' ), __( 'Sat', 'candela-parohia' ), __( 'Sun', 'candela-parohia' ) ) as $candela_zs ) : ?>
				<div class="candela-luna__zi-sapt" aria-hidden="true"><?php echo esc_html( $candela_zs ); ?></div>
			<?php endforeach; ?>
			<?php for ( $candela_i = 0; $candela_i < $candela_gol; $candela_i++ ) : ?>
				<div class="candela-luna__celula candela-luna__celula--goala" aria-hidden="true"></div>
			<?php endfor; ?>
			<?php for ( $candela_d = 1; $candela_d <= $candela_nr; $candela_d++ ) : ?>
				<?php
				$candela_data = $candela_prima->format( 'Y-m-' ) . sprintf( '%02d', $candela_d );
				$candela_sl   = $candela_grupe[ $candela_data ] ?? array();
				$candela_per  = array_values( array_unique( array_filter( array_column( $candela_sl, 'perioada' ) ) ) );
				?>
				<div class="candela-luna__celula<?php echo $candela_data === $candela_azi ? ' candela-luna__celula--azi' : ''; ?><?php echo $candela_sl ? '' : ' candela-luna__celula--libera'; ?><?php echo $candela_data < $candela_azi ? ' candela-luna__celula--trecut' : ''; ?>" role="listitem">
					<p class="candela-luna__data"><span class="candela-luna__nr"><?php echo (int) $candela_d; ?></span><span class="candela-luna__zi-lunga"><?php echo esc_html( $candela_zi_txt( $candela_data, 'l, j F' ) ); ?></span></p>
					<?php if ( $candela_per ) : ?><p class="candela-program__perioada"><?php echo esc_html( implode( ', ', $candela_per ) ); ?></p><?php endif; ?>
					<?php if ( $candela_sl ) : ?>
						<ul class="candela-program__lista"><?php echo implode( '', array_map( $candela_rand_html, $candela_sl ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the closure. ?></ul>
					<?php endif; ?>
				</div>
			<?php endfor; ?>
		</div>
	</div>

<?php elseif ( 'lista' === $candela_vedere ) : ?>
	<p class="candela-program__tipar"><button type="button" class="wp-element-button" onclick="window.print()"><?php esc_html_e( 'Print the schedule', 'candela-parohia' ); ?></button></p>
	<?php if ( ! $candela_grupe ) : ?>
		<p class="candela-program__gol"><?php esc_html_e( 'The schedule will be announced soon.', 'candela-parohia' ); ?></p>
	<?php endif; ?>
	<table class="candela-program__tabel">
		<tbody>
		<?php foreach ( $candela_grupe as $candela_data => $candela_sl ) : ?>
			<?php foreach ( $candela_sl as $candela_k => $candela_s ) : ?>
				<tr class="<?php echo 0 === $candela_k ? 'candela-program__prima' : ''; ?> candela-program__slujba--<?php echo esc_attr( $candela_s['categorie'] ); ?>">
					<?php if ( 0 === $candela_k ) : ?>
						<th scope="rowgroup" rowspan="<?php echo count( $candela_sl ); ?>"><?php echo esc_html( $candela_zi_txt( $candela_data, 'l, j F' ) ); ?>
							<?php $candela_per = array_values( array_unique( array_filter( array_column( $candela_sl, 'perioada' ) ) ) ); ?>
							<?php if ( $candela_per ) : ?><span class="candela-program__perioada"><?php echo esc_html( implode( ', ', $candela_per ) ); ?></span><?php endif; ?>
						</th>
					<?php endif; ?>
					<td class="candela-program__ora"><?php echo esc_html( $candela_s['ora'] ); ?></td>
					<td><?php echo esc_html( $candela_s['slujba'] ); ?>
						<?php if ( '' !== $candela_s['nota'] ) : ?><span class="candela-program__nota"><?php echo esc_html( $candela_s['nota'] ); ?></span><?php endif; ?>
						<?php if ( '' !== $candela_s['loc'] ) : ?><span class="candela-program__loc"><?php echo esc_html( $candela_s['loc'] ); ?></span><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endforeach; ?>
		</tbody>
	</table>

<?php else : ?>
	<?php if ( ! $candela_grupe ) : ?>
		<p class="candela-program__gol"><?php esc_html_e( 'The schedule will be announced soon.', 'candela-parohia' ); ?></p>
	<?php endif; ?>
	<?php foreach ( $candela_grupe as $candela_data => $candela_slujbe ) : ?>
		<?php $candela_per = array_values( array_unique( array_filter( array_column( $candela_slujbe, 'perioada' ) ) ) ); ?>
		<div class="candela-program__zi<?php echo $candela_data === $candela_azi ? ' candela-program__zi--azi' : ''; ?>">
			<p class="candela-program__data">
				<?php if ( $candela_data === $candela_azi ) : ?>
					<span class="candela-program__eticheta"><?php esc_html_e( 'Today', 'candela-parohia' ); ?></span>
				<?php endif; ?>
				<?php echo esc_html( $candela_zi_txt( $candela_data, 'l, j F' ) ); ?>
			</p>
			<?php if ( $candela_per ) : ?><p class="candela-program__perioada"><?php echo esc_html( implode( ', ', $candela_per ) ); ?></p><?php endif; ?>
			<ul class="candela-program__lista"><?php echo implode( '', array_map( $candela_rand_html, $candela_slujbe ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the closure. ?></ul>
		</div>
	<?php endforeach; ?>
<?php endif; ?>
</div>
