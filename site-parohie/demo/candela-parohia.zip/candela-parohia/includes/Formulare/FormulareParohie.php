<?php
/**
 * Parish form types on top of the core forms engine: pomelnic and service booking.
 *
 * The pomelnic asks only for baptismal first names (data minimisation: GDPR art. 5 and 9).
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Formulare;

use Candela\Core\Modul;

/**
 * Parish forms module.
 */
final class FormulareParohie implements Modul {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'candela_formulare', array( $this, 'tipuri' ) );
		add_filter( 'candela_bara_actiuni', array( $this, 'actiune_pomelnic' ), 20 );
	}

	/**
	 * Services that can be booked. Filterable per parish.
	 *
	 * @return string[]
	 */
	public static function slujbe_programabile(): array {
		/**
		 * Filters the services offered in the booking form.
		 *
		 * @since 0.1.0
		 * @param string[] $slujbe Service names.
		 */
		return (array) apply_filters(
			'candela_slujbe_programabile',
			array(
				__( 'Baptism', 'candela-parohia' ),
				__( 'Wedding', 'candela-parohia' ),
				__( 'Confession', 'candela-parohia' ),
				__( 'House blessing', 'candela-parohia' ),
				__( 'Memorial service (parastas)', 'candela-parohia' ),
				__( 'Holy Unction', 'candela-parohia' ),
				__( 'Other service', 'candela-parohia' ),
			)
		);
	}

	/**
	 * Adds `pomelnic` and `programare`.
	 *
	 * @param array $tipuri Form types.
	 */
	public function tipuri( array $tipuri ): array {
		$tipuri['pomelnic'] = array(
			'titlu'          => __( 'Names for prayer', 'candela-parohia' ),
			'eticheta_panou' => __( 'Pomelnice received', 'candela-parohia' ),
			'buton'          => __( 'Send the pomelnic', 'candela-parohia' ),
			'multumire'      => __( 'Thank you! The names will be commemorated at the Divine Liturgy.', 'candela-parohia' ),
			'consimtamant'   => __( 'I agree that the parish keeps these names in order to commemorate them in prayer. They are deleted automatically after the retention period.', 'candela-parohia' ),
			'campuri'        => array(
				array(
					'nume'        => 'pentru',
					'eticheta'    => __( 'The pomelnic is', 'candela-parohia' ),
					'tip'         => 'radio',
					'obligatoriu' => true,
					'optiuni'     => array(
						'vii'      => __( 'For the living (health and salvation)', 'candela-parohia' ),
						'adormiti' => __( 'For the departed (rest)', 'candela-parohia' ),
					),
				),
				array(
					'nume'        => 'nume',
					'eticheta'    => __( 'Names', 'candela-parohia' ),
					'tip'         => 'textarea',
					'obligatoriu' => true,
					'randuri'     => 7,
					'ajutor'      => __( 'Only baptismal first names, one per line, without surnames (e.g. Ioan, Maria, Fr. Gheorghe).', 'candela-parohia' ),
				),
				array(
					'nume'     => 'slujba',
					'eticheta' => __( 'At which service', 'candela-parohia' ),
					'tip'      => 'select',
					'optiuni'  => array(
						'liturghie' => __( 'At the Divine Liturgy', 'candela-parohia' ),
						'acatist'   => __( 'At the Akathist or Paraklesis', 'candela-parohia' ),
						'parastas'  => __( 'At a memorial service (for the departed)', 'candela-parohia' ),
					),
				),
				array(
					'nume'     => 'trimis_de',
					'eticheta' => __( 'Your name (optional)', 'candela-parohia' ),
					'tip'      => 'text',
				),
			),
		);
		$tipuri['programare'] = array(
			'titlu'          => __( 'Booking', 'candela-parohia' ),
			'eticheta_panou' => __( 'Bookings received', 'candela-parohia' ),
			'buton'          => __( 'Send the request', 'candela-parohia' ),
			'multumire'      => __( 'Thank you! The priest will contact you to confirm the date.', 'candela-parohia' ),
			'consimtamant'   => __( 'I agree that the parish keeps these details in order to arrange the service. They are deleted automatically after the retention period.', 'candela-parohia' ),
			'campuri'        => array(
				array( 'nume' => 'slujba', 'eticheta' => __( 'Service', 'candela-parohia' ), 'tip' => 'select', 'obligatoriu' => true, 'optiuni' => self::slujbe_programabile() ),
				array( 'nume' => 'data', 'eticheta' => __( 'Preferred date', 'candela-parohia' ), 'tip' => 'date', 'obligatoriu' => true ),
				array( 'nume' => 'moment', 'eticheta' => __( 'Preferred time of day', 'candela-parohia' ), 'tip' => 'select', 'optiuni' => array( 'dimineata' => __( 'Morning', 'candela-parohia' ), 'dupa-amiaza' => __( 'Afternoon', 'candela-parohia' ), 'seara' => __( 'Evening', 'candela-parohia' ), 'oricand' => __( 'Any time', 'candela-parohia' ) ) ),
				array( 'nume' => 'nume', 'eticheta' => __( 'Your name', 'candela-parohia' ), 'tip' => 'text', 'obligatoriu' => true ),
				array( 'nume' => 'telefon', 'eticheta' => __( 'Phone', 'candela-parohia' ), 'tip' => 'tel', 'obligatoriu' => true ),
				array( 'nume' => 'email', 'eticheta' => __( 'E-mail (optional)', 'candela-parohia' ), 'tip' => 'email' ),
				array( 'nume' => 'detalii', 'eticheta' => __( 'Details (optional)', 'candela-parohia' ), 'tip' => 'textarea', 'randuri' => 4 ),
			),
		);
		return $tipuri;
	}

	/**
	 * The pomelnic link in the phone quick-actions bar.
	 *
	 * @param array $actiuni Actions.
	 */
	public function actiune_pomelnic( array $actiuni ): array {
		$actiuni[] = array(
			'eticheta' => __( 'Names for prayer', 'candela-parohia' ),
			'url'      => home_url( '/pomelnic/' ),
			'icon'     => 'lumanare',
		);
		return $actiuni;
	}
}
