<?php
/**
 * Bootstraps the core and every registered module.
 *
 * @package Candela\Core
 */

namespace Candela\Core;

/**
 * Loads modules listed by the `candela_module` filter.
 */
final class Plugin {

	/**
	 * Module instances, by class name.
	 *
	 * @var array<class-string, Modul>
	 */
	private static array $module = array();

	/**
	 * Runs on `plugins_loaded` (priority 5), so verticals hooked at the default priority 10 of the
	 * same action are too late; verticals therefore add their classes through the filter, which is
	 * read here, after every plugin file has been included.
	 */
	public static function boot(): void {
		add_action( 'init', array( self::class, 'traduceri' ), 1 );
		add_filter( 'render_block_core/group', array( self::class, 'limba_bloc' ), 10, 2 );

		/**
		 * Filters the list of module classes to load.
		 *
		 * @since 0.1.0
		 * @param class-string<Modul>[] $clase Module class names.
		 */
		$clase = (array) apply_filters( 'candela_module', array( Organizatie\Organizatie::class, Articole\Articole::class, Formulare\Formulare::class, Panou\Panou::class, Mentenanta\Mentenanta::class, Actualizari\Actualizari::class ) );

		foreach ( array_unique( $clase ) as $clasa ) {
			if ( ! class_exists( $clasa ) || ! is_subclass_of( $clasa, Modul::class ) ) {
				_doing_it_wrong( __METHOD__, esc_html( "Candela: {$clasa} is not a Candela\\Core\\Modul." ), '0.1.0' );
				continue;
			}
			self::$module[ $clasa ] = new $clasa();
			self::$module[ $clasa ]->register();
		}
	}

	/**
	 * A group with the class `candela-lang-xx` gets `lang="xx"` (the page in the country language:
	 * correct pronunciation for screen readers, correct language for search engines).
	 *
	 * @param string $html  Rendered block.
	 * @param array  $block Block.
	 */
	public static function limba_bloc( string $html, array $block ): string {
		$clase = (string) ( $block['attrs']['className'] ?? '' );
		if ( ! preg_match( '/(?:^|\s)candela-lang-([a-z]{2})(?:\s|$)/', $clase, $m ) ) {
			return $html;
		}
		$p = new \WP_HTML_Tag_Processor( $html );
		if ( $p->next_tag() ) {
			$p->set_attribute( 'lang', $m[1] );
			return $p->get_updated_html();
		}
		return $html;
	}

	/**
	 * Plugin activation: default categories, the parish editor role, the daily clean-up.
	 */
	public static function activare(): void {
		Articole\Articole::categorii();
		Panou\Panou::roluri();
	}

	/**
	 * Plugin deactivation: stop the scheduled clean-up.
	 */
	public static function dezactivare(): void {
		wp_clear_scheduled_hook( Formulare\Formulare::CRON );
	}

	/**
	 * Loads translations (on `init`, as required since WordPress 6.7).
	 */
	public static function traduceri(): void {
		load_plugin_textdomain( 'candela-core', false, dirname( plugin_basename( CANDELA_CORE_DIR . '/candela-core.php' ) ) . '/languages' );
	}

	/**
	 * Returns a loaded module instance, or null.
	 *
	 * @param class-string $clasa Module class.
	 */
	public static function modul( string $clasa ): ?Modul {
		return self::$module[ $clasa ] ?? null;
	}
}
