<?php
/**
 * Plugin Name:       Candela Parohia
 * Description:       Orthodox parish vertical for the Candela kit: services and weekly schedule, Orthodox calendar and Paschalion, commemoration lists, sacrament bookings.
 * Version:           0.3.4
 * Update URI:        https://researchmind.org/site-parohie/actualizari/
 * Requires at least: 6.9
 * Requires PHP:      8.1
 * Requires Plugins:  candela-core
 * Author:            Candela Parohiei
 * License:           GPL-2.0-or-later
 * Text Domain:       candela-parohia
 * Domain Path:       /languages
 *
 * @package Candela\Parohia
 */

defined( 'ABSPATH' ) || exit;

define( 'CANDELA_PAROHIA_VERSION', '0.3.4' );
define( 'CANDELA_PAROHIA_DIR', __DIR__ );
define( 'CANDELA_PAROHIA_FILE', __FILE__ );

spl_autoload_register(
	static function ( string $clasa ): void {
		$prefix = 'Candela\\Parohia\\';
		if ( 0 !== strpos( $clasa, $prefix ) ) {
			return;
		}
		$fisier = __DIR__ . '/includes/' . str_replace( '\\', '/', substr( $clasa, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $fisier ) ) {
			require $fisier;
		}
	}
);

/*
 * Register this vertical's modules with the core. The filter is read by the core on
 * `plugins_loaded`, after all plugin files are included, so load order does not matter.
 */
add_filter(
	'candela_module',
	static function ( array $clase ): array {
		$clase[] = Candela\Parohia\Calendar\Calendar::class;
		$clase[] = Candela\Parohia\Slujbe\Slujbe::class;
		$clase[] = Candela\Parohia\Formulare\FormulareParohie::class;
		return $clase;
	}
);

add_action(
	'init',
	static function (): void {
		load_plugin_textdomain( 'candela-parohia', false, dirname( plugin_basename( CANDELA_PAROHIA_FILE ) ) . '/languages' );
	},
	1
);
