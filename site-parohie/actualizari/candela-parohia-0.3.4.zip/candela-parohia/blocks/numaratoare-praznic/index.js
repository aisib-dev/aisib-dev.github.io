/**
 * Editor side of candela/numaratoare-praznic. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;

	wp.blocks.registerBlockType( 'candela/numaratoare-praznic', {
		edit: function ( props ) {
			var blockProps = wp.blockEditor.useBlockProps();
			return el(
				'div',
				blockProps,
				el(
					wp.blockEditor.InspectorControls,
					null,
					el(
						wp.components.PanelBody,
						{ title: __( 'Settings', 'candela-parohia' ) },
						el( wp.components.ToggleControl, {
							label: __( 'Great feasts only', 'candela-parohia' ),
							checked: !! props.attributes.doarImparatesti,
							onChange: function ( v ) {
								props.setAttributes( { doarImparatesti: v } );
							},
						} )
					)
				),
				el( wp.serverSideRender, {
					block: 'candela/numaratoare-praznic',
					attributes: props.attributes,
				} )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
