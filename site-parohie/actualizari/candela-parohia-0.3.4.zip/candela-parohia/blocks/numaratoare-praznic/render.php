<?php
/**
 * Server render of candela/numaratoare-praznic.
 *
 * @package Candela\Parohia
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

$candela_tipuri = ! empty( $attributes['doarImparatesti'] ) ? array( 'imparatesc' ) : array( 'imparatesc', 'mare' );
$candela_text   = Candela\Parohia\Calendar\Calendar::text_numaratoare( $candela_tipuri );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'candela-numaratoare' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-escaped. ?>>
	<?php $candela_url = (string) ( $attributes['url'] ?? '' ); ?>
	<?php if ( '' !== $candela_url ) : ?><a class="candela-numaratoare__link" href="<?php echo esc_url( $candela_url ); ?>"><?php endif; ?>
	<p class="candela-numaratoare__text"><?php echo wp_kses( $candela_text, array( 'strong' => array(), 'span' => array( 'class' => true ) ) ); ?></p>
	<?php if ( '' !== $candela_url ) : ?></a><?php endif; ?>
</div>
