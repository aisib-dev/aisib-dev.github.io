/**
 * Editor side of candela/program-slujbe. Plain ES5 with WordPress globals: no build step needed.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;

	wp.blocks.registerBlockType( 'candela/program-slujbe', {
		edit: function ( props ) {
			var blockProps = wp.blockEditor.useBlockProps();
			return el(
				'div',
				blockProps,
				el(
					wp.blockEditor.InspectorControls,
					null,
					el(
						wp.components.PanelBody,
						{ title: __( 'Settings', 'candela-parohia' ) },
						el( wp.components.SelectControl, {
							label: __( 'View', 'candela-parohia' ),
							value: props.attributes.vedere,
							options: [
								{ label: __( 'Next days (cards)', 'candela-parohia' ), value: 'zile' },
								{ label: __( 'Month calendar', 'candela-parohia' ), value: 'luna' },
								{ label: __( 'Printable list', 'candela-parohia' ), value: 'lista' },
							],
							onChange: function ( v ) {
								props.setAttributes( { vedere: v } );
							},
						} ),
						el( wp.components.RangeControl, {
							label: __( 'Days shown', 'candela-parohia' ),
							min: 1,
							max: 62,
							value: props.attributes.zile,
							onChange: function ( v ) {
								props.setAttributes( { zile: v } );
							},
						} )
					)
				),
				el( wp.serverSideRender, {
					block: 'candela/program-slujbe',
					attributes: props.attributes,
				} )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
