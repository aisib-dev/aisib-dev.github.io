<?php
/**
 * «Programul săptămânii» admin page: usual week, special periods, changes on a date.
 * Built for a non-technical priest: plain tables, no dates to type for the Paschal periods.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Slujbe;

/**
 * Schedule admin page.
 */
final class AdminProgram {

	public const PAGINA = 'candela-program';

	/**
	 * Hooks.
	 */
	public function register(): void {
		add_filter( 'candela_butoane_panou', array( $this, 'buton_panou' ) );
		add_action( 'admin_menu', array( $this, 'meniu' ), 20 );
		add_action( 'admin_post_candela_program_salveaza', array( $this, 'salveaza' ) );
	}

	/**
	 * «Weekly schedule» button on the parish dashboard.
	 *
	 * @param array $butoane Buttons.
	 */
	public function buton_panou( array $butoane ): array {
		$butoane[] = array(
			'eticheta'  => __( 'Weekly schedule', 'candela-parohia' ),
			'descriere' => __( 'Usual services, fasts and feasts, changes.', 'candela-parohia' ),
			'url'       => admin_url( 'admin.php?page=' . self::PAGINA ),
			'icon'      => 'clock',
			'cap'       => 'candela_program',
			'ordine'    => 3,
		);
		return $butoane;
	}

	/**
	 * Admin page under the parish dashboard.
	 */
	public function meniu(): void {
		add_submenu_page( 'candela-panou', __( 'Weekly schedule', 'candela-parohia' ), __( 'Weekly schedule', 'candela-parohia' ), 'candela_program', self::PAGINA, array( $this, 'pagina' ) );
	}

	/**
	 * Day names.
	 *
	 * @return array<string, string>
	 */
	private static function zile(): array {
		return array(
			'luni'     => __( 'Monday', 'candela-parohia' ),
			'marti'    => __( 'Tuesday', 'candela-parohia' ),
			'miercuri' => __( 'Wednesday', 'candela-parohia' ),
			'joi'      => __( 'Thursday', 'candela-parohia' ),
			'vineri'   => __( 'Friday', 'candela-parohia' ),
			'sambata'  => __( 'Saturday', 'candela-parohia' ),
			'duminica' => __( 'Sunday', 'candela-parohia' ),
		);
	}

	/**
	 * Month names (for fixed period bounds).
	 *
	 * @return array<int, string>
	 */
	private static function luni(): array {
		global $wp_locale;
		$l = array();
		for ( $m = 1; $m <= 12; $m++ ) {
			$l[ $m ] = $wp_locale ? $wp_locale->get_month( $m ) : (string) $m;
		}
		return $l;
	}

	/**
	 * Editable rows of a template (usual week or a period), with 2 empty rows at the end.
	 *
	 * @param string $prefix  Field name prefix, e.g. "sablon" or "perioade[0][sablon]".
	 * @param array  $randuri Existing rows.
	 */
	private static function randuri( string $prefix, array $randuri ): void {
		$randuri = array_merge( $randuri, array_fill( 0, 2, array() ) );
		echo '<div class="candela-program-admin__randuri">';
		foreach ( $randuri as $i => $r ) {
			$n = $prefix . '[' . (int) $i . ']';
			?>
			<div class="candela-program-admin__rand">
				<label><?php esc_html_e( 'Day', 'candela-parohia' ); ?>
					<select name="<?php echo esc_attr( $n ); ?>[zi]">
						<option value=""></option>
						<?php foreach ( self::zile() as $k => $z ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $r['zi'] ?? '', $k ); ?>><?php echo esc_html( $z ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label><?php esc_html_e( 'Time', 'candela-parohia' ); ?>
					<input type="time" name="<?php echo esc_attr( $n ); ?>[ora]" value="<?php echo esc_attr( $r['ora'] ?? '' ); ?>">
				</label>
				<label class="lat"><?php esc_html_e( 'Service or activity', 'candela-parohia' ); ?>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[slujba]" value="<?php echo esc_attr( $r['slujba'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'e.g. Divine Liturgy', 'candela-parohia' ); ?>">
				</label>
				<label><?php esc_html_e( 'Kind', 'candela-parohia' ); ?>
					<select name="<?php echo esc_attr( $n ); ?>[categorie]">
						<option value="slujba" <?php selected( $r['categorie'] ?? 'slujba', 'slujba' ); ?>><?php esc_html_e( 'Service', 'candela-parohia' ); ?></option>
						<option value="activitate" <?php selected( $r['categorie'] ?? '', 'activitate' ); ?>><?php esc_html_e( 'Activity (catechesis, choir…)', 'candela-parohia' ); ?></option>
					</select>
				</label>
				<label class="mediu"><?php esc_html_e( 'Place (optional)', 'candela-parohia' ); ?>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[loc]" value="<?php echo esc_attr( $r['loc'] ?? '' ); ?>">
				</label>
				<fieldset><legend><?php esc_html_e( 'Only in weeks', 'candela-parohia' ); ?></legend>
					<?php for ( $s = 1; $s <= 5; $s++ ) : ?>
						<label class="mic"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[saptamani][]" value="<?php echo (int) $s; ?>" <?php checked( in_array( $s, array_map( 'intval', (array) ( $r['saptamani'] ?? array() ) ), true ) ); ?>> <?php echo (int) $s; ?></label>
					<?php endfor; ?>
				</fieldset>
			</div>
			<?php
		}
		echo '</div>';
	}

	/**
	 * Human description of a period's dates.
	 *
	 * @param array $p Period.
	 */
	private static function interval_text( array $p ): string {
		if ( str_starts_with( (string) $p['de'], 'P' ) || str_starts_with( (string) $p['pana'], 'P' ) ) {
			$an = (int) current_datetime()->format( 'Y' );
			$d1 = Program::limita( (string) $p['de'], $an );
			$d2 = Program::limita( (string) $p['pana'], $an );
			if ( $d1 && $d2 && $d2 < current_datetime()->setTime( 0, 0 ) ) {
				++$an;
				$d1 = Program::limita( (string) $p['de'], $an );
				$d2 = Program::limita( (string) $p['pana'], $an );
			}
			$utc = new \DateTimeZone( 'UTC' );
			return $d1 && $d2 && $d2 >= $d1
				/* translators: 1: start date, 2: end date. */
				? sprintf( __( 'Follows the Paschalion by itself; this year: %1$s to %2$s.', 'candela-parohia' ), wp_date( 'j F Y', $d1->getTimestamp(), $utc ), wp_date( 'j F Y', $d2->getTimestamp(), $utc ) )
				: __( 'Follows the Paschalion by itself; this year it does not occur.', 'candela-parohia' );
		}
		$l = self::luni();
		/* translators: 1: start day and month, 2: end day and month. */
		return sprintf( __( 'Every year, from %1$s to %2$s.', 'candela-parohia' ), (int) substr( $p['de'], 3 ) . ' ' . $l[ (int) substr( $p['de'], 0, 2 ) ], (int) substr( $p['pana'], 3 ) . ' ' . $l[ (int) substr( $p['pana'], 0, 2 ) ] );
	}

	/**
	 * Day + month selects for a fixed bound.
	 *
	 * @param string $nume   Field name.
	 * @param string $valoare Current value MM-DD.
	 */
	private static function zi_luna( string $nume, string $valoare ): void {
		$z = (int) substr( $valoare, 3, 2 );
		$m = (int) substr( $valoare, 0, 2 );
		echo '<select name="' . esc_attr( $nume ) . '[zi]">';
		for ( $i = 1; $i <= 31; $i++ ) {
			echo '<option value="' . (int) $i . '"' . selected( $z, $i, false ) . '>' . (int) $i . '</option>';
		}
		echo '</select> <select name="' . esc_attr( $nume ) . '[luna]">';
		foreach ( self::luni() as $i => $l ) {
			echo '<option value="' . (int) $i . '"' . selected( $m, $i, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select>';
	}

	/**
	 * The page.
	 */
	public function pagina(): void {
		$prog     = get_option( Slujbe::OPTIUNE, array() );
		$perioade = is_array( $prog['perioade'] ?? null ) ? $prog['perioade'] : array();
		$exceptii = get_posts(
			array(
				'post_type'      => Slujbe::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'meta_key'       => 'candela_data', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'        => 'meta_value',
				'order'          => 'ASC',
				'meta_query'     => array( array( 'key' => 'candela_data', 'value' => current_datetime()->format( 'Y-m-d' ), 'compare' => '>=', 'type' => 'DATE' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		$folosite = array_column( $perioade, 'preset' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag.
		$salvat = isset( $_GET['salvat'] );
		?>
		<div class="wrap candela-panou candela-program-admin">
			<p class="candela-panou__inapoi"><a href="<?php echo esc_url( admin_url( 'admin.php?page=candela-panou' ) ); ?>">&larr; <?php esc_html_e( 'Parish dashboard', 'candela-parohia' ); ?></a></p>
			<h1><?php esc_html_e( 'Weekly schedule', 'candela-parohia' ); ?></h1>
			<?php if ( $salvat ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Saved. The website shows the new schedule.', 'candela-parohia' ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="candela_program_salveaza">
				<?php wp_nonce_field( 'candela_program' ); ?>

				<h2><?php esc_html_e( '1. The usual week', 'candela-parohia' ); ?></h2>
				<p class="candela-panou__sub"><?php esc_html_e( 'These repeat every week by themselves. Leave a row empty to remove it.', 'candela-parohia' ); ?></p>
				<?php self::randuri( 'sablon', is_array( $prog['sablon'] ?? null ) ? $prog['sablon'] : array() ); ?>
				<p>
					<label><?php esc_html_e( 'On weekday feasts, add the Divine Liturgy at', 'candela-parohia' ); ?>
						<input type="time" name="ora_praznice" value="<?php echo esc_attr( $prog['ora_praznice'] ?? '' ); ?>">
					</label>
					<span class="description"><?php esc_html_e( 'Leave empty if not needed.', 'candela-parohia' ); ?></span>
				</p>

				<h2><?php esc_html_e( '2. Fasts and special periods', 'candela-parohia' ); ?></h2>
				<p class="candela-panou__sub"><?php esc_html_e( 'A period either adds services to the usual week (e.g. the Presanctified Liturgy in Great Lent) or replaces it (e.g. Holy Week). The Paschal periods move with Pascha by themselves.', 'candela-parohia' ); ?></p>
				<?php foreach ( $perioade as $i => $p ) : ?>
					<?php $n = 'perioade[' . (int) $i . ']'; ?>
					<details class="candela-program-admin__perioada" <?php echo empty( $p['sablon'] ) ? 'open' : ''; ?>>
						<summary>
							<strong><?php echo esc_html( $p['nume'] ); ?></strong>
							<span><?php echo esc_html( 'inlocuieste' === $p['mod'] ? __( 'replaces the usual week', 'candela-parohia' ) : __( 'adds to the usual week', 'candela-parohia' ) ); ?> &middot; <?php echo esc_html( self::interval_text( $p ) ); ?></span>
						</summary>
						<input type="hidden" name="<?php echo esc_attr( $n ); ?>[preset]" value="<?php echo esc_attr( $p['preset'] ); ?>">
						<div class="candela-program-admin__rand">
							<label class="lat"><?php esc_html_e( 'Name', 'candela-parohia' ); ?>
								<input type="text" name="<?php echo esc_attr( $n ); ?>[nume]" value="<?php echo esc_attr( $p['nume'] ); ?>">
							</label>
							<?php if ( isset( Program::PRESETURI[ $p['preset'] ] ) ) : ?>
								<input type="hidden" name="<?php echo esc_attr( $n ); ?>[de]" value="<?php echo esc_attr( $p['de'] ); ?>">
								<input type="hidden" name="<?php echo esc_attr( $n ); ?>[pana]" value="<?php echo esc_attr( $p['pana'] ); ?>">
							<?php else : ?>
								<label><?php esc_html_e( 'From', 'candela-parohia' ); ?> <span><?php self::zi_luna( $n . '[de]', $p['de'] ); ?></span></label>
								<label><?php esc_html_e( 'To', 'candela-parohia' ); ?> <span><?php self::zi_luna( $n . '[pana]', $p['pana'] ); ?></span></label>
							<?php endif; ?>
							<fieldset><legend><?php esc_html_e( 'This period', 'candela-parohia' ); ?></legend>
								<label class="mic"><input type="radio" name="<?php echo esc_attr( $n ); ?>[mod]" value="adauga" <?php checked( $p['mod'], 'adauga' ); ?>> <?php esc_html_e( 'adds services', 'candela-parohia' ); ?></label>
								<label class="mic"><input type="radio" name="<?php echo esc_attr( $n ); ?>[mod]" value="inlocuieste" <?php checked( $p['mod'], 'inlocuieste' ); ?>> <?php esc_html_e( 'replaces the usual week', 'candela-parohia' ); ?></label>
							</fieldset>
							<label class="mic candela-program-admin__sterge"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[sterge]" value="1"> <?php esc_html_e( 'remove this period', 'candela-parohia' ); ?></label>
						</div>
						<?php self::randuri( $n . '[sablon]', (array) $p['sablon'] ); ?>
					</details>
				<?php endforeach; ?>
				<p class="candela-program-admin__adauga">
					<label><?php esc_html_e( 'Add a period', 'candela-parohia' ); ?>
						<select name="adauga_perioada">
							<option value=""></option>
							<?php foreach ( Slujbe::nume_preseturi() as $k => $nume ) : ?>
								<?php if ( ! in_array( $k, $folosite, true ) ) : ?>
									<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $nume ); ?></option>
								<?php endif; ?>
							<?php endforeach; ?>
							<option value="alta"><?php esc_html_e( 'Another period (summer, parish feast…), with dates', 'candela-parohia' ); ?></option>
						</select>
					</label>
					<span class="description"><?php esc_html_e( 'After saving, it appears above and you fill in its services.', 'candela-parohia' ); ?></span>
				</p>

				<h2><?php esc_html_e( '3. Changes on a date (extra or cancelled services)', 'candela-parohia' ); ?></h2>
				<?php if ( $exceptii ) : ?>
					<ul class="candela-program-admin__exceptii">
						<?php foreach ( $exceptii as $p ) : ?>
							<li>
								<strong><?php $zi = wp_date( 'l, j F', strtotime( (string) get_post_meta( $p->ID, 'candela_data', true ) . ' 12:00' ) ); echo esc_html( mb_strtoupper( mb_substr( $zi, 0, 1 ) ) . mb_substr( $zi, 1 ) ); ?>, <?php echo esc_html( (string) get_post_meta( $p->ID, 'candela_ora', true ) ); ?></strong>
								&middot; <?php echo esc_html( get_the_title( $p ) ); ?>
								<?php if ( get_post_meta( $p->ID, 'candela_anulata', true ) ) : ?><em>(<?php esc_html_e( 'cancelled', 'candela-parohia' ); ?>)</em><?php endif; ?>
								<label class="mic"><input type="checkbox" name="sterge_exceptii[]" value="<?php echo (int) $p->ID; ?>"> <?php esc_html_e( 'remove', 'candela-parohia' ); ?></label>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<div class="candela-program-admin__rand">
					<label><?php esc_html_e( 'Date', 'candela-parohia' ); ?> <input type="date" name="noua[data]" min="<?php echo esc_attr( current_datetime()->format( 'Y-m-d' ) ); ?>"></label>
					<label><?php esc_html_e( 'Time', 'candela-parohia' ); ?> <input type="time" name="noua[ora]"></label>
					<label class="lat"><?php esc_html_e( 'Service', 'candela-parohia' ); ?> <input type="text" name="noua[slujba]"></label>
					<label class="lat"><?php esc_html_e( 'Place (optional)', 'candela-parohia' ); ?> <input type="text" name="noua[loc]"></label>
					<label class="mic"><input type="checkbox" name="noua[anulata]" value="1"> <?php esc_html_e( 'Cancel the usual service at this date and time', 'candela-parohia' ); ?></label>
				</div>
				<p class="candela-program-admin__salveaza"><button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Save the schedule', 'candela-parohia' ); ?></button></p>
			</form>
		</div>
		<?php
	}

	/**
	 * MM-DD from a [zi, luna] pair, or the string itself if already a bound.
	 *
	 * @param mixed $v Value.
	 */
	private static function limita_din( $v ): string {
		if ( is_array( $v ) ) {
			return sprintf( '%02d-%02d', (int) ( $v['luna'] ?? 1 ), (int) ( $v['zi'] ?? 1 ) );
		}
		return (string) $v;
	}

	/**
	 * Saves the page.
	 */
	public function salveaza(): void {
		check_admin_referer( 'candela_program' );
		if ( ! current_user_can( 'candela_program' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'candela-parohia' ) );
		}
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- everything goes through Slujbe::curata().
		$perioade = array();
		foreach ( (array) wp_unslash( $_POST['perioade'] ?? array() ) as $p ) {
			if ( ! empty( $p['sterge'] ) ) {
				continue;
			}
			$p['de']    = self::limita_din( $p['de'] ?? '' );
			$p['pana']  = self::limita_din( $p['pana'] ?? '' );
			$perioade[] = $p;
		}
		$nou = sanitize_key( wp_unslash( $_POST['adauga_perioada'] ?? '' ) );
		if ( isset( Program::PRESETURI[ $nou ] ) ) {
			$perioade[] = array(
				'preset' => $nou,
				'nume'   => Slujbe::nume_preseturi()[ $nou ],
				'de'     => Program::PRESETURI[ $nou ][1],
				'pana'   => Program::PRESETURI[ $nou ][2],
				'mod'    => 'saptamana-mare' === $nou ? 'inlocuieste' : 'adauga',
				'sablon' => array(),
			);
		} elseif ( 'alta' === $nou ) {
			$perioade[] = array( 'preset' => '', 'nume' => __( 'New period', 'candela-parohia' ), 'de' => '07-01', 'pana' => '08-31', 'mod' => 'adauga', 'sablon' => array() );
		}
		update_option(
			Slujbe::OPTIUNE,
			Slujbe::curata(
				array(
					'sablon'       => array_values( (array) wp_unslash( $_POST['sablon'] ?? array() ) ),
					'perioade'     => $perioade,
					'ora_praznice' => sanitize_text_field( wp_unslash( $_POST['ora_praznice'] ?? '' ) ),
				)
			)
		);
		foreach ( array_map( 'absint', (array) ( $_POST['sterge_exceptii'] ?? array() ) ) as $id ) {
			if ( Slujbe::CPT === get_post_type( $id ) ) {
				wp_delete_post( $id, true );
			}
		}
		$n = (array) wp_unslash( $_POST['noua'] ?? array() );
		// phpcs:enable
		$data = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $n['data'] ?? '' ) ) ? $n['data'] : '';
		$ora  = Slujbe::ora_valida( (string) ( $n['ora'] ?? '' ) ) ? $n['ora'] : '';
		$sl   = sanitize_text_field( $n['slujba'] ?? '' );
		if ( $data && $ora && ( $sl || ! empty( $n['anulata'] ) ) ) {
			$id = wp_insert_post( array( 'post_type' => Slujbe::CPT, 'post_status' => 'publish', 'post_title' => $sl ? $sl : __( 'Cancelled service', 'candela-parohia' ) ) );
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, 'candela_data', $data );
				update_post_meta( $id, 'candela_ora', $ora );
				update_post_meta( $id, 'candela_loc', sanitize_text_field( $n['loc'] ?? '' ) );
				update_post_meta( $id, 'candela_anulata', ! empty( $n['anulata'] ) );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGINA . '&salvat=1' ) );
		exit;
	}
}
