<?php
/**
 * Services module: data and the public block.
 * - option `candela_program`: usual week, special periods, feast Liturgy time;
 * - private post type `candela_slujba`: exceptions (extra or cancelled services on a date);
 * - block `candela/program-slujbe` (days, month or printable list).
 * The admin page lives in AdminProgram.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Slujbe;

use Candela\Core\Modul;
use Candela\Parohia\Calendar\Calendar;
use Candela\Parohia\Calendar\Nume;
use Candela\Parohia\Calendar\Sarbatori;

/**
 * Services module.
 */
final class Slujbe implements Modul {

	public const OPTIUNE = 'candela_program';
	public const CPT     = 'candela_slujba';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'tip_continut' ) );
		add_action( 'init', array( $this, 'setare' ) );
		add_action( 'init', array( $this, 'bloc' ) );
		add_filter( 'candela_bara_actiuni', array( $this, 'actiuni' ) );
		( new AdminProgram() )->register();
	}

	/**
	 * Adds "Schedule" to the phone quick-actions bar.
	 *
	 * @param array $actiuni Actions.
	 */
	public function actiuni( array $actiuni ): array {
		$actiuni[] = array(
			'eticheta' => __( 'Schedule', 'candela-parohia' ),
			'url'      => home_url( '/#program' ),
			'icon'     => 'ceas',
		);
		return $actiuni;
	}

	/**
	 * Exceptions: one post per extra or cancelled service. Not public; edited from the dashboard.
	 */
	public function tip_continut(): void {
		register_post_type(
			self::CPT,
			array(
				'label'           => __( 'Services', 'candela-parohia' ),
				'labels'          => array(
					'name'          => __( 'Services', 'candela-parohia' ),
					'singular_name' => __( 'Service', 'candela-parohia' ),
					'add_new_item'  => __( 'Add service', 'candela-parohia' ),
				),
				'public'          => false,
				'show_ui'         => false,
				'show_in_rest'    => true,
				'supports'        => array( 'title', 'custom-fields' ),
				'capability_type' => 'post',
			)
		);
		$meta = array(
			'candela_data'    => array( 'type' => 'string', 'description' => 'Y-m-d' ),
			'candela_ora'     => array( 'type' => 'string', 'description' => 'H:i' ),
			'candela_loc'     => array( 'type' => 'string' ),
			'candela_nota'    => array( 'type' => 'string' ),
			'candela_anulata' => array( 'type' => 'boolean' ),
		);
		foreach ( $meta as $cheie => $def ) {
			register_post_meta(
				self::CPT,
				$cheie,
				array_merge(
					$def,
					array(
						'single'        => true,
						'show_in_rest'  => true,
						'auth_callback' => static fn() => current_user_can( 'edit_posts' ),
					)
				)
			);
		}
	}

	/**
	 * The schedule option.
	 */
	public function setare(): void {
		register_setting(
			'candela',
			self::OPTIUNE,
			array(
				'type'              => 'object',
				'default'           => array( 'sablon' => array(), 'perioade' => array(), 'ora_praznice' => '' ),
				'sanitize_callback' => array( self::class, 'curata' ),
				'show_in_rest'      => array( 'schema' => array( 'type' => 'object', 'additionalProperties' => true ) ),
			)
		);
	}

	/**
	 * Sanitises one template row; null if incomplete.
	 *
	 * @param mixed $s Row.
	 */
	public static function curata_rand( $s ): ?array {
		$s = (array) $s;
		if ( ! isset( Program::ZILE[ $s['zi'] ?? '' ] ) || ! self::ora_valida( (string) ( $s['ora'] ?? '' ) ) || '' === trim( (string) ( $s['slujba'] ?? '' ) ) ) {
			return null;
		}
		return array(
			'zi'        => (string) $s['zi'],
			'ora'       => (string) $s['ora'],
			'slujba'    => sanitize_text_field( (string) $s['slujba'] ),
			'saptamani' => array_values( array_filter( array_map( 'intval', (array) ( $s['saptamani'] ?? array() ) ), static fn( $n ) => $n >= 1 && $n <= 5 ) ),
			'loc'       => sanitize_text_field( (string) ( $s['loc'] ?? '' ) ),
			'nota'      => sanitize_text_field( (string) ( $s['nota'] ?? '' ) ),
			'categorie' => 'activitate' === ( $s['categorie'] ?? '' ) ? 'activitate' : 'slujba',
		);
	}

	/**
	 * HH:MM check.
	 *
	 * @param string $x Value.
	 */
	public static function ora_valida( string $x ): bool {
		return (bool) preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $x );
	}

	/**
	 * Sanitises the whole option.
	 *
	 * @param mixed $v Submitted value.
	 */
	public static function curata( $v ): array {
		$v   = (array) $v;
		$out = array(
			'sablon'       => array(),
			'perioade'     => array(),
			'ora_praznice' => self::ora_valida( (string) ( $v['ora_praznice'] ?? '' ) ) ? (string) $v['ora_praznice'] : '',
		);
		foreach ( (array) ( $v['sablon'] ?? array() ) as $s ) {
			$r = self::curata_rand( $s );
			if ( $r ) {
				$out['sablon'][] = $r;
			}
		}
		$limita = '/^(P[+-]\d{1,3}|(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/';
		foreach ( array_slice( (array) ( $v['perioade'] ?? array() ), 0, 12 ) as $p ) {
			$p = (array) $p;
			if ( ! preg_match( $limita, (string) ( $p['de'] ?? '' ) ) || ! preg_match( $limita, (string) ( $p['pana'] ?? '' ) ) ) {
				continue;
			}
			$randuri = array();
			foreach ( (array) ( $p['sablon'] ?? array() ) as $s ) {
				$r = self::curata_rand( $s );
				if ( $r ) {
					$randuri[] = $r;
				}
			}
			$out['perioade'][] = array(
				'preset' => sanitize_key( (string) ( $p['preset'] ?? '' ) ),
				'nume'   => sanitize_text_field( (string) ( $p['nume'] ?? '' ) ),
				'de'     => (string) $p['de'],
				'pana'   => (string) $p['pana'],
				'mod'    => 'inlocuieste' === ( $p['mod'] ?? '' ) ? 'inlocuieste' : 'adauga',
				'sablon' => $randuri,
			);
		}
		return $out;
	}

	/**
	 * Registers the schedule block.
	 */
	public function bloc(): void {
		register_block_type( CANDELA_PAROHIA_DIR . '/blocks/program-slujbe' );
	}

	/**
	 * Services from a day (default: today, in the site's time zone) for $zile days.
	 *
	 * @param int                     $zile  Number of days (max 62).
	 * @param \DateTimeImmutable|null $start First day.
	 */
	public static function urmatoarele( int $zile = 7, ?\DateTimeImmutable $start = null ): array {
		$zile   = max( 1, min( 62, $zile ) );
		$start  = $start ?? current_datetime();
		$prog   = get_option( self::OPTIUNE, array() );
		$sablon = is_array( $prog['sablon'] ?? null ) ? $prog['sablon'] : array();
		$per    = is_array( $prog['perioade'] ?? null ) ? $prog['perioade'] : array();
		$ora_p  = (string) ( $prog['ora_praznice'] ?? '' );

		$postari = get_posts(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- small, bounded set.
					array(
						'key'     => 'candela_data',
						'value'   => array( $start->format( 'Y-m-d' ), $start->modify( '+' . $zile . ' days' )->format( 'Y-m-d' ) ),
						'compare' => 'BETWEEN',
						'type'    => 'DATE',
					),
				),
			)
		);
		$exceptii = array();
		foreach ( $postari as $p ) {
			$exceptii[] = array(
				'data'    => (string) get_post_meta( $p->ID, 'candela_data', true ),
				'ora'     => (string) get_post_meta( $p->ID, 'candela_ora', true ),
				'slujba'  => get_the_title( $p ),
				'loc'     => (string) get_post_meta( $p->ID, 'candela_loc', true ),
				'nota'    => (string) get_post_meta( $p->ID, 'candela_nota', true ),
				'anulata' => (bool) get_post_meta( $p->ID, 'candela_anulata', true ),
			);
		}

		$praznice = array();
		if ( '' !== $ora_p ) {
			$extra = Calendar::extra();
			$an    = (int) $start->format( 'Y' );
			foreach ( array( $an, $an + 1 ) as $a ) {
				foreach ( Sarbatori::anul( $a, $extra ) as $s ) {
					$praznice[] = array( 'data' => $s['data'], 'nume' => Nume::get( $s['cheie'], $extra ) );
				}
			}
		}

		return Program::interval( $sablon, $exceptii, $start, $zile, $praznice, $ora_p, __( 'Divine Liturgy', 'candela-parohia' ), $per );
	}

	/**
	 * Translated names of the preset periods (literal strings, for translation tools).
	 *
	 * @return array<string, string>
	 */
	public static function nume_preseturi(): array {
		return array(
			'postul-mare'        => __( 'Great Lent', 'candela-parohia' ),
			'saptamana-mare'     => __( 'Holy Week', 'candela-parohia' ),
			'saptamana-luminata' => __( 'Bright Week', 'candela-parohia' ),
			'postul-apostolilor' => __( 'Fast of the Holy Apostles', 'candela-parohia' ),
			'postul-adormirii'   => __( 'Dormition Fast', 'candela-parohia' ),
			'postul-nasterii'    => __( 'Nativity Fast', 'candela-parohia' ),
		);
	}
}
