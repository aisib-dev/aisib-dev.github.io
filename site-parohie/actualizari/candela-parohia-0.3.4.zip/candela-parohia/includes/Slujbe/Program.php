<?php
/**
 * Builds the list of services and activities for a range of days from:
 * - the usual week (template),
 * - special periods of the year (Great Lent, Holy Week, Nativity Fast, summer…), each with its own
 *   template that either replaces or adds to the usual week; bounds are fixed dates (MM-DD) or
 *   offsets from Pascha (P-48, P+6), so movable periods follow the Paschalion by themselves,
 * - exceptions entered by the priest (extra or cancelled services on a date),
 * - weekday feasts (automatic Divine Liturgy).
 * Pure PHP, unit-tested.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Slujbe;

use Candela\Parohia\Calendar\Pascalie;

/**
 * Schedule calculator.
 */
final class Program {

	/** Romanian day keys used in the client profile => ISO-8601 day number. */
	public const ZILE = array(
		'luni'     => 1,
		'marti'    => 2,
		'miercuri' => 3,
		'joi'      => 4,
		'vineri'   => 5,
		'sambata'  => 6,
		'duminica' => 7,
	);

	/**
	 * Preset periods: key => [name (English source, translated by the caller), from, to].
	 * Bounds: 'MM-DD' (fixed) or 'P±N' (days from Pascha).
	 */
	public const PRESETURI = array(
		'postul-mare'        => array( 'Great Lent', 'P-48', 'P-9' ),
		'saptamana-mare'     => array( 'Holy Week', 'P-6', 'P-1' ),
		'saptamana-luminata' => array( 'Bright Week', 'P+1', 'P+6' ),
		'postul-apostolilor' => array( 'Fast of the Holy Apostles', 'P+57', '06-28' ),
		'postul-adormirii'   => array( 'Dormition Fast', '08-01', '08-14' ),
		'postul-nasterii'    => array( 'Nativity Fast', '11-15', '12-24' ),
	);

	/**
	 * Services between $start (inclusive) and $start + $zile (exclusive).
	 *
	 * @param array              $sablon         Usual week: list of [zi, ora, slujba, saptamani?, loc?, nota?, categorie?].
	 * @param array              $exceptii       List of [data Y-m-d, ora, slujba, anulata?, loc?, nota?].
	 * @param \DateTimeImmutable $start          First day.
	 * @param int                $zile           Number of days.
	 * @param array              $praznice       List of [data DateTimeImmutable, nume] for weekday feasts.
	 * @param string             $ora_praznice   Time of the feast-day Liturgy ('' = do not add).
	 * @param string             $nume_liturghie Display name of the Liturgy (translated by the caller).
	 * @param array              $perioade       List of [nume, de, pana, mod ('adauga'|'inlocuieste'), sablon].
	 * @return list<array{data:string, ora:string, slujba:string, loc:string, nota:string, sursa:string, categorie:string, perioada:string}>
	 */
	public static function interval( array $sablon, array $exceptii, \DateTimeImmutable $start, int $zile, array $praznice = array(), string $ora_praznice = '', string $nume_liturghie = 'Divine Liturgy', array $perioade = array() ): array {
		$zi0  = new \DateTimeImmutable( $start->format( 'Y-m-d' ), new \DateTimeZone( 'UTC' ) );
		$out  = array();
		$anul = array();

		foreach ( $exceptii as $e ) {
			if ( ! empty( $e['anulata'] ) ) {
				$anul[ $e['data'] . ' ' . $e['ora'] ] = true;
			}
		}

		for ( $i = 0; $i < $zile; $i++ ) {
			$zi    = $zi0->modify( "+{$i} days" );
			$data  = $zi->format( 'Y-m-d' );
			$iso   = (int) $zi->format( 'N' );
			$saptl = intdiv( (int) $zi->format( 'j' ) - 1, 7 ) + 1; // Nth weekday of the month.

			// Which templates apply today: the usual week, unless a replacing period is active; plus adding periods.
			$active   = array_values( array_filter( $perioade, static fn( $p ) => self::activa( $p, $zi ) ) );
			$inlocuit = null;
			foreach ( $active as $p ) {
				if ( 'inlocuieste' === ( $p['mod'] ?? 'adauga' ) ) {
					$inlocuit = $p; // The last one listed wins (more specific periods go lower).
				}
			}
			$surse = array( array( $inlocuit ? (array) ( $inlocuit['sablon'] ?? array() ) : $sablon, $inlocuit ? (string) $inlocuit['nume'] : '' ) );
			foreach ( $active as $p ) {
				if ( 'inlocuieste' !== ( $p['mod'] ?? 'adauga' ) ) {
					$surse[] = array( (array) ( $p['sablon'] ?? array() ), (string) ( $p['nume'] ?? '' ) );
				}
			}

			foreach ( $surse as list( $rand_sablon, $nume_perioada ) ) {
				foreach ( $rand_sablon as $s ) {
					if ( ( self::ZILE[ $s['zi'] ?? '' ] ?? 0 ) !== $iso ) {
						continue;
					}
					if ( ! empty( $s['saptamani'] ) && ! in_array( $saptl, array_map( 'intval', $s['saptamani'] ), true ) ) {
						continue;
					}
					if ( isset( $anul[ $data . ' ' . ( $s['ora'] ?? '' ) ] ) ) {
						continue;
					}
					$out[] = self::rand( $data, $s, 'sablon', $nume_perioada );
				}
			}

			foreach ( $exceptii as $e ) {
				if ( empty( $e['anulata'] ) && ( $e['data'] ?? '' ) === $data ) {
					$out[] = self::rand( $data, $e, 'exceptie' );
				}
			}

			if ( '' !== $ora_praznice && 7 !== $iso ) {
				foreach ( $praznice as $p ) {
					if ( $p['data']->format( 'Y-m-d' ) !== $data ) {
						continue;
					}
					$are_liturghie = false;
					foreach ( $out as $r ) {
						if ( $r['data'] === $data && false !== stripos( $r['slujba'], $nume_liturghie ) ) {
							$are_liturghie = true;
						}
					}
					if ( ! $are_liturghie ) {
						$out[] = self::rand(
							$data,
							array(
								'ora'    => $ora_praznice,
								'slujba' => $nume_liturghie,
								'nota'   => $p['nume'],
							),
							'praznic'
						);
					}
					break; // One Liturgy per day, even if two feasts share the date.
				}
			}
		}

		usort( $out, static fn( $a, $b ) => array( $a['data'], $a['ora'] ) <=> array( $b['data'], $b['ora'] ) );
		return $out;
	}

	/**
	 * Resolves a bound ('MM-DD' or 'P±N') to a date in a given year; null if invalid.
	 *
	 * @param string $limita Bound.
	 * @param int    $an     Year.
	 */
	public static function limita( string $limita, int $an ): ?\DateTimeImmutable {
		$utc = new \DateTimeZone( 'UTC' );
		if ( preg_match( '/^P([+-]\d{1,3})$/', $limita, $m ) ) {
			return Pascalie::pastile( $an )->modify( sprintf( '%+d days', (int) $m[1] ) );
		}
		if ( preg_match( '/^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/', $limita ) && checkdate( (int) substr( $limita, 0, 2 ), (int) substr( $limita, 3, 2 ), $an ) ) {
			return new \DateTimeImmutable( $an . '-' . $limita, $utc );
		}
		return null;
	}

	/**
	 * Whether a period is active on a day. Fixed periods may cross the new year (12-25 → 01-07).
	 * A period whose end comes before its start in the same year (e.g. a short Apostles' Fast that
	 * vanishes) is skipped, except for fixed periods crossing the new year.
	 *
	 * @param array              $p  Period.
	 * @param \DateTimeImmutable $zi Day (UTC midnight).
	 */
	public static function activa( array $p, \DateTimeImmutable $zi ): bool {
		$de   = (string) ( $p['de'] ?? '' );
		$pana = (string) ( $p['pana'] ?? '' );
		$an   = (int) $zi->format( 'Y' );
		$fixe = ! str_starts_with( $de, 'P' ) && ! str_starts_with( $pana, 'P' );
		foreach ( array( $an, $an - 1 ) as $a ) {
			$d1 = self::limita( $de, $a );
			if ( ! $d1 ) {
				return false;
			}
			$d2 = self::limita( $pana, $a );
			if ( ! $d2 ) {
				return false;
			}
			if ( $d2 < $d1 ) {
				if ( ! $fixe ) {
					continue; // Empty movable period this year.
				}
				$d2 = self::limita( $pana, $a + 1 ); // Crosses the new year.
			}
			if ( $zi >= $d1 && $zi <= $d2 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Normalised row.
	 *
	 * @param string $data     Date.
	 * @param array  $s        Source row.
	 * @param string $sursa    Origin: sablon | exceptie | praznic.
	 * @param string $perioada Period name ('' = usual week).
	 */
	private static function rand( string $data, array $s, string $sursa, string $perioada = '' ): array {
		return array(
			'data'      => $data,
			'ora'       => (string) ( $s['ora'] ?? '' ),
			'slujba'    => (string) ( $s['slujba'] ?? '' ),
			'loc'       => (string) ( $s['loc'] ?? '' ),
			'nota'      => (string) ( $s['nota'] ?? '' ),
			'sursa'     => $sursa,
			'categorie' => 'activitate' === ( $s['categorie'] ?? '' ) ? 'activitate' : 'slujba',
			'perioada'  => $perioada,
		);
	}
}
