<?php
/**
 * Calendar module: the parish patron feast, the `candela_sarbatori` filter and the countdown block.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Calendar;

use Candela\Core\Modul;
use Candela\Core\Organizatie\Organizatie;

/**
 * Calendar module.
 */
final class Calendar implements Modul {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		// The patron feast date (MM-DD) becomes one more organisation field.
		add_filter(
			'candela_campuri_organizatie',
			static function ( array $campuri ): array {
				$campuri[] = 'hram_data';
				return $campuri;
			}
		);
		add_action( 'init', array( $this, 'blocuri' ) );
	}

	/**
	 * Registers the blocks of this module.
	 */
	public function blocuri(): void {
		register_block_type( CANDELA_PAROHIA_DIR . '/blocks/numaratoare-praznic' );
	}

	/**
	 * Extra feasts for the current site: the patron feast plus whatever extensions add.
	 *
	 * @return array<string, array{0:string,1:string,2?:string}> key => [MM-DD, kind, name].
	 */
	public static function extra(): array {
		$extra = array();
		$data  = Organizatie::get( 'hram_data' );
		if ( preg_match( '/^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/', $data ) ) {
			$hram = Organizatie::get( 'hram' );
			/* translators: %s: name of the parish patron saint or feast. */
			$extra['hram'] = array( $data, 'mare', $hram ? sprintf( __( 'the patron feast: %s', 'candela-parohia' ), $hram ) : __( 'the patron feast', 'candela-parohia' ) );
		}
		/**
		 * Filters the extra feasts (local saints, the eparchy's feasts).
		 *
		 * @since 0.1.0
		 * @param array $extra key => [MM-DD, kind ('imparatesc'|'mare'), display name].
		 */
		return (array) apply_filters( 'candela_sarbatori', $extra );
	}

	/**
	 * Countdown sentence for today, safe HTML.
	 *
	 * @param string[] $tipuri Kinds to consider.
	 */
	public static function text_numaratoare( array $tipuri = array( 'imparatesc', 'mare' ) ): string {
		$extra = self::extra();
		$s     = Sarbatori::urmatoarea( current_datetime(), $extra, $tipuri );
		$nume  = esc_html( Nume::get( $s['cheie'], $extra ) );

		if ( 0 === $s['zile'] ) {
			/* translators: %s: feast name. */
			return sprintf( __( 'Today we celebrate %s', 'candela-parohia' ), '<strong>' . $nume . '</strong>' );
		}
		if ( 1 === $s['zile'] ) {
			/* translators: %s: feast name. */
			return sprintf( __( 'Tomorrow we celebrate %s', 'candela-parohia' ), '<strong>' . $nume . '</strong>' );
		}
		$zile = '<span class="candela-numaratoare__zile">' . (int) $s['zile'] . '</span>';
		return sprintf(
			/* translators: 1: number of days (HTML), 2: feast name. */
			_n( '%1$s day until %2$s', '%1$s days until %2$s', $s['zile'], 'candela-parohia' ),
			$zile,
			'<strong>' . $nume . '</strong>'
		);
	}
}
