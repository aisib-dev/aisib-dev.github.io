<?php
/**
 * The list of feasts of a year and the "next feast" lookup.
 *
 * Pure PHP. Fixed feasts follow the Revised Julian calendar used by the Romanian Orthodox Church
 * (same day and month as the civil calendar); movable feasts come from Pascalie.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Calendar;

/**
 * Feast list.
 */
final class Sarbatori {

	/**
	 * Fixed feasts: key => [month-day, kind]. Kinds: 'imparatesc' (Great Feast of the Lord or of the
	 * Mother of God, marked with a red cross), 'mare' (great saint or feast kept by the parish).
	 */
	public const FIXE = array(
		'taierea-imprejur-sf-vasile'    => array( '01-01', 'mare' ),
		'botezul-domnului'              => array( '01-06', 'imparatesc' ),
		'sf-ioan-botezatorul-soborul'   => array( '01-07', 'mare' ),
		'sfintii-trei-ierarhi'          => array( '01-30', 'mare' ),
		'intampinarea-domnului'         => array( '02-02', 'imparatesc' ),
		'buna-vestire'                  => array( '03-25', 'imparatesc' ),
		'sf-gheorghe'                   => array( '04-23', 'mare' ),
		'sf-constantin-elena'           => array( '05-21', 'mare' ),
		'nasterea-sf-ioan-botezatorul'  => array( '06-24', 'mare' ),
		'sf-petru-pavel'                => array( '06-29', 'mare' ),
		'sf-ilie'                       => array( '07-20', 'mare' ),
		'schimbarea-la-fata'            => array( '08-06', 'imparatesc' ),
		'adormirea-maicii-domnului'     => array( '08-15', 'imparatesc' ),
		'taierea-capului-sf-ioan'       => array( '08-29', 'mare' ),
		'nasterea-maicii-domnului'      => array( '09-08', 'imparatesc' ),
		'inaltarea-sfintei-cruci'       => array( '09-14', 'imparatesc' ),
		'sf-parascheva'                 => array( '10-14', 'mare' ),
		'sf-dimitrie'                   => array( '10-26', 'mare' ),
		'sf-arhangheli'                 => array( '11-08', 'mare' ),
		'intrarea-in-biserica'          => array( '11-21', 'imparatesc' ),
		'sf-andrei'                     => array( '11-30', 'mare' ),
		'sf-nicolae'                    => array( '12-06', 'mare' ),
		'nasterea-domnului'             => array( '12-25', 'imparatesc' ),
		'soborul-maicii-domnului'       => array( '12-26', 'mare' ),
		'sf-stefan'                     => array( '12-27', 'mare' ),
	);

	/** Movable feasts shown in the countdown, with their kind. */
	public const MOBILE_AFISATE = array(
		'intrarea-in-ierusalim'   => 'imparatesc',
		'pastile'               => 'imparatesc',
		'izvorul-tamaduirii'      => 'mare',
		'inaltarea-domnului'      => 'imparatesc',
		'pogorarea-duhului-sfant' => 'imparatesc',
		'sfanta-treime'           => 'mare',
	);

	/**
	 * Feasts of a year, sorted by date.
	 *
	 * @param int                                        $an     Year.
	 * @param array<string, array{0:string,1:string}>    $extra  Extra fixed feasts (e.g. the parish's patron), same shape as FIXE.
	 * @return list<array{cheie:string, data:\DateTimeImmutable, tip:string}>
	 */
	public static function anul( int $an, array $extra = array() ): array {
		$utc = new \DateTimeZone( 'UTC' );
		$out = array();
		foreach ( array_merge( self::FIXE, $extra ) as $cheie => list( $md, $tip ) ) {
			$out[] = array(
				'cheie' => $cheie,
				'data'  => new \DateTimeImmutable( $an . '-' . $md, $utc ),
				'tip'   => $tip,
			);
		}
		$mobile = Pascalie::mobile( $an );
		foreach ( self::MOBILE_AFISATE as $cheie => $tip ) {
			$out[] = array(
				'cheie' => $cheie,
				'data'  => $mobile[ $cheie ],
				'tip'   => $tip,
			);
		}
		usort( $out, static fn( $x, $y ) => $x['data'] <=> $y['data'] );
		return $out;
	}

	/**
	 * The first feast on or after a day, with the number of days left.
	 *
	 * @param \DateTimeImmutable $azi    Today (only the date part is used).
	 * @param array              $extra  Extra fixed feasts, as in anul().
	 * @param string[]           $tipuri Kinds to consider.
	 * @return array{cheie:string, data:\DateTimeImmutable, tip:string, zile:int}
	 */
	public static function urmatoarea( \DateTimeImmutable $azi, array $extra = array(), array $tipuri = array( 'imparatesc', 'mare' ) ): array {
		$zi = new \DateTimeImmutable( $azi->format( 'Y-m-d' ), new \DateTimeZone( 'UTC' ) );
		$an = (int) $zi->format( 'Y' );
		foreach ( array( $an, $an + 1 ) as $a ) {
			foreach ( self::anul( $a, $extra ) as $s ) {
				if ( in_array( $s['tip'], $tipuri, true ) && $s['data'] >= $zi ) {
					$s['zile'] = (int) $zi->diff( $s['data'] )->days;
					return $s;
				}
			}
		}
		throw new \RuntimeException( 'No feast found.' ); // Unreachable with a non-empty list.
	}
}
