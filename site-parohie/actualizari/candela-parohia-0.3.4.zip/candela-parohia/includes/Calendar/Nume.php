<?php
/**
 * Display names of the feasts. Literal strings, so translation tools can extract them.
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Calendar;

/**
 * Feast names (English source, translated through `candela-parohia`).
 */
final class Nume {

	/**
	 * Name of a feast by key; extra feasts may carry their own name as third element.
	 *
	 * @param string $cheie Feast key.
	 * @param array  $extra Extra feasts (key => [month-day, kind, name]).
	 */
	public static function get( string $cheie, array $extra = array() ): string {
		$toate = self::toate();
		if ( isset( $toate[ $cheie ] ) ) {
			return $toate[ $cheie ];
		}
		return isset( $extra[ $cheie ][2] ) ? (string) $extra[ $cheie ][2] : $cheie;
	}

	/**
	 * All built-in names.
	 *
	 * @return array<string, string>
	 */
	public static function toate(): array {
		return array(
			'taierea-imprejur-sf-vasile'   => __( 'Circumcision of the Lord; Saint Basil the Great', 'candela-parohia' ),
			'botezul-domnului'             => __( 'Theophany (Baptism of the Lord)', 'candela-parohia' ),
			'sf-ioan-botezatorul-soborul'  => __( 'Synaxis of Saint John the Baptist', 'candela-parohia' ),
			'sfintii-trei-ierarhi'         => __( 'The Three Holy Hierarchs', 'candela-parohia' ),
			'intampinarea-domnului'        => __( 'Meeting of the Lord', 'candela-parohia' ),
			'buna-vestire'                 => __( 'Annunciation', 'candela-parohia' ),
			'sf-gheorghe'                  => __( 'Saint George the Great Martyr', 'candela-parohia' ),
			'sf-constantin-elena'          => __( 'Saints Constantine and Helen', 'candela-parohia' ),
			'nasterea-sf-ioan-botezatorul' => __( 'Nativity of Saint John the Baptist', 'candela-parohia' ),
			'sf-petru-pavel'               => __( 'Holy Apostles Peter and Paul', 'candela-parohia' ),
			'sf-ilie'                      => __( 'Holy Prophet Elijah', 'candela-parohia' ),
			'schimbarea-la-fata'           => __( 'Transfiguration of the Lord', 'candela-parohia' ),
			'adormirea-maicii-domnului'    => __( 'Dormition of the Mother of God', 'candela-parohia' ),
			'taierea-capului-sf-ioan'      => __( 'Beheading of Saint John the Baptist', 'candela-parohia' ),
			'nasterea-maicii-domnului'     => __( 'Nativity of the Mother of God', 'candela-parohia' ),
			'inaltarea-sfintei-cruci'      => __( 'Exaltation of the Holy Cross', 'candela-parohia' ),
			'sf-parascheva'                => __( 'Saint Paraskeva', 'candela-parohia' ),
			'sf-dimitrie'                  => __( 'Saint Demetrius the Myrrh-streamer', 'candela-parohia' ),
			'sf-arhangheli'                => __( 'Holy Archangels Michael and Gabriel', 'candela-parohia' ),
			'intrarea-in-biserica'         => __( 'Entry of the Mother of God into the Temple', 'candela-parohia' ),
			'sf-andrei'                    => __( 'Holy Apostle Andrew', 'candela-parohia' ),
			'sf-nicolae'                   => __( 'Saint Nicholas', 'candela-parohia' ),
			'nasterea-domnului'            => __( 'Nativity of the Lord (Christmas)', 'candela-parohia' ),
			'soborul-maicii-domnului'      => __( 'Synaxis of the Mother of God', 'candela-parohia' ),
			'sf-stefan'                    => __( 'Holy Archdeacon Stephen', 'candela-parohia' ),
			'intrarea-in-ierusalim'        => __( 'Entry of the Lord into Jerusalem (Palm Sunday)', 'candela-parohia' ),
			'pastile'                      => __( 'Resurrection of the Lord (Pascha)', 'candela-parohia' ),
			'izvorul-tamaduirii'           => __( 'Life-giving Spring', 'candela-parohia' ),
			'inaltarea-domnului'           => __( 'Ascension of the Lord', 'candela-parohia' ),
			'pogorarea-duhului-sfant'      => __( 'Pentecost', 'candela-parohia' ),
			'sfanta-treime'                => __( 'Holy Trinity', 'candela-parohia' ),
		);
	}
}
