<?php
/**
 * Orthodox Paschalion: date of Pascha and of the movable feasts.
 *
 * Pure PHP, no WordPress dependency, so it can be unit-tested anywhere.
 * Pascha is computed on the Julian calendar (Meeus' Julian algorithm) and converted to the civil
 * (Gregorian) calendar. Does not need PHP's `calendar` extension (absent on some hosts).
 *
 * @package Candela\Parohia
 */

namespace Candela\Parohia\Calendar;

/**
 * Paschalion helpers.
 */
final class Pascalie {

	/**
	 * Movable feasts, as day offsets from Pascha (Romanian Orthodox usage).
	 * Keys are stable identifiers; display names live in Nume::movabile().
	 */
	public const MOBILE = array(
		'duminica-vamesului-fariseului' => -70,
		'duminica-fiului-risipitor'     => -63,
		'duminica-infricosatoarei-judecati' => -56,
		'duminica-izgonirii-adam'       => -49,
		'inceputul-postului-mare'       => -48,
		'duminica-ortodoxiei'           => -42,
		'intrarea-in-ierusalim'         => -7,
		'joia-mare'                     => -3,
		'vinerea-mare'                  => -2,
		'pastile'                       => 0,
		'izvorul-tamaduirii'            => 5,
		'duminica-tomii'                => 7,
		'inaltarea-domnului'            => 39,
		'pogorarea-duhului-sfant'       => 49,
		'sfanta-treime'                 => 50,
		'duminica-tuturor-sfintilor'    => 56,
	);

	/**
	 * Date of Orthodox Pascha in the civil (Gregorian) calendar.
	 *
	 * @param int $an Year, 1900-2099 (the Julian/Gregorian gap is 13 days in that range).
	 * @return \DateTimeImmutable Midnight, in UTC; callers compare dates, not times.
	 * @throws \InvalidArgumentException Outside the supported range.
	 */
	public static function pastile( int $an ): \DateTimeImmutable {
		if ( $an < 1900 || $an > 2099 ) {
			throw new \InvalidArgumentException( 'Supported years: 1900-2099.' );
		}
		$a     = $an % 4;
		$b     = $an % 7;
		$c     = $an % 19;
		$d     = ( 19 * $c + 15 ) % 30;
		$e     = ( 2 * $a + 4 * $b - $d + 34 ) % 7;
		$luna  = intdiv( $d + $e + 114, 31 );
		$ziua  = ( ( $d + $e + 114 ) % 31 ) + 1;
		$iulian = new \DateTimeImmutable( sprintf( '%04d-%02d-%02d', $an, $luna, $ziua ), new \DateTimeZone( 'UTC' ) );
		return $iulian->modify( '+13 days' );
	}

	/**
	 * All movable feasts of a year.
	 *
	 * @param int $an Year.
	 * @return array<string, \DateTimeImmutable> Key => date.
	 */
	public static function mobile( int $an ): array {
		$pasti = self::pastile( $an );
		$out   = array();
		foreach ( self::MOBILE as $cheie => $zile ) {
			$out[ $cheie ] = $pasti->modify( sprintf( '%+d days', $zile ) );
		}
		return $out;
	}
}
