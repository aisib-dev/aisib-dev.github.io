<?php
/**
 * Title: Post grid (blog and archives)
 * Slug: candela/lista-articole
 * Inserter: no
 * Description: Paginated grid of posts with image, date, title and excerpt. Used by home.html and archive.html.
 *
 * @package Candela\Theme
 */

?>
<!-- wp:query {"queryId":2,"query":{"perPage":9,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":true},"align":"wide"} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"className":"candela-grila-articole","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"260px"}} -->
<!-- wp:group {"className":"candela-card-articol","style":{"spacing":{"blockGap":"0.4rem","padding":{"bottom":"1.2rem"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group candela-card-articol" style="padding-bottom:1.2rem"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","className":"candela-card-articol__imagine"} /-->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"1.2rem","right":"1.2rem","top":"0.6rem"},"blockGap":"0.3rem"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-top:0.6rem;padding-right:1.2rem;padding-left:1.2rem"><!-- wp:post-date /-->

<!-- wp:post-title {"isLink":true,"level":2,"fontSize":"large"} /-->

<!-- wp:post-excerpt {"excerptLength":22} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-numbers /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Nothing published yet.', 'candela' ); ?></p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results --></div>
<!-- /wp:query -->
