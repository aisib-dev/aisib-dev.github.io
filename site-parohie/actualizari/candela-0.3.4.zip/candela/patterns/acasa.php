<?php
/**
 * Title: Home page of a parish
 * Slug: candela/acasa
 * Categories: featured
 * Keywords: parish, home, acasa
 * Description: Hero with the parish name and feast countdown, weekly services, announcements, quick actions, contact.
 * Viewport Width: 1280
 *
 * @package Candela\Theme
 */

?>
<!-- wp:group {"align":"full","className":"candela-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"backgroundColor":"primary","textColor":"base","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-hero has-base-color has-primary-background-color has-text-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"candela-hero__salut"} -->
<p class="candela-hero__salut"><?php echo esc_html__( 'Welcome', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":1,"metadata":{"bindings":{"content":{"source":"candela/organizatie","args":{"key":"nume"}}}}} -->
<h1 class="wp-block-heading has-text-align-center"></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"candela-hram","fontSize":"large","metadata":{"bindings":{"content":{"source":"candela/organizatie","args":{"key":"hram"}}}}} -->
<p class="has-text-align-center candela-hram has-large-font-size"></p>
<!-- /wp:paragraph -->

<!-- wp:candela/numaratoare-praznic {"url":"#program","fontSize":"medium"} /-->

<!-- wp:buttons {"className":"candela-hero__butoane","layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons candela-hero__butoane"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#program"><?php echo esc_html__( 'Service schedule', 'candela' ); ?></a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/pomelnic/"><?php echo esc_html__( 'Send names for prayer', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","className":"candela-rapid","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide candela-rapid"><!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"className":"candela-rapid__program"} -->
<div class="wp-block-column candela-rapid__program"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="#program"><?php echo esc_html__( 'Service schedule', 'candela' ); ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'This week, this month, the fasts and feasts.', 'candela' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"candela-rapid__pomelnic"} -->
<div class="wp-block-column candela-rapid__pomelnic"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/pomelnic/"><?php echo esc_html__( 'Names for prayer', 'candela' ); ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Names of the living and the departed, for the Liturgy.', 'candela' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"candela-rapid__programare"} -->
<div class="wp-block-column candela-rapid__programare"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/slujbe/"><?php echo esc_html__( 'Book a service', 'candela' ); ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Baptism, wedding, house blessing, memorial.', 'candela' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"candela-rapid__sprijin"} -->
<div class="wp-block-column candela-rapid__sprijin"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/sprijin/"><?php echo esc_html__( 'Support', 'candela' ); ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'The parish account and online giving.', 'candela' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","className":"candela-banda-urm","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide candela-banda-urm"><!-- wp:candela/program-slujbe {"vedere":"urmatoarea"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"program","align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div id="program" class="wp-block-group alignfull candela-sectiune has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center","className":"candela-eticheta"} -->
<p class="has-text-align-center candela-eticheta"><?php echo esc_html__( 'Prayer of the parish', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Services this week', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/program-slujbe {"zile":7,"align":"wide"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune candela-anunturi","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune candela-anunturi" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center","className":"candela-eticheta"} -->
<p class="has-text-align-center candela-eticheta"><?php echo esc_html__( 'News', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Announcements', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/articole {"categorie":"anunturi","aspect":"lista","numar":3} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune candela-viata","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune candela-viata" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:media-text {"align":"wide","mediaType":"image","verticalAlignment":"center"} -->
<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center"><figure class="wp-block-media-text__media"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/comunitate.jpg' ) ); ?>" alt="<?php echo esc_attr__( 'Families walking to church on a Sunday morning', 'candela' ); ?>"/></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"className":"candela-hero__salut"} -->
<p class="candela-hero__salut"><?php echo esc_html__( 'Parish life', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'A living parish', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html__( 'Around the Divine Liturgy the parish gathers as a family: catechesis for children, the choir, help for those in need, the feasts we prepare together.', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class="wp-block-quote"><!-- wp:paragraph -->
<p><?php echo esc_html__( 'Come and see.', 'candela' ); ?></p>
<!-- /wp:paragraph --><cite><?php echo esc_html__( 'John 1:46', 'candela' ); ?></cite></blockquote>
<!-- /wp:quote -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/despre/"><?php echo esc_html__( 'About the parish', 'candela' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center","className":"candela-eticheta"} -->
<p class="has-text-align-center candela-eticheta"><?php echo esc_html__( 'A word that helps', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'From the parish blog', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:candela/articole {"categorie":"articole","aspect":"carduri","numar":3,"align":"wide"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"candela-sectiune","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull candela-sectiune" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center","className":"candela-eticheta"} -->
<p class="has-text-align-center candela-eticheta"><?php echo esc_html__( 'We are waiting for you', 'candela' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'How to find us', 'candela' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","className":"candela-gaseste"} -->
<div class="wp-block-columns alignwide candela-gaseste"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:group {"className":"candela-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group candela-card"><!-- wp:candela/contact /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:candela/harta /--></div>
<!-- /wp:column --><!-- /wp:columns --></div>
<!-- /wp:group -->
