<?php
/**
 * Title: Blog page heading
 * Slug: candela/titlu-blog
 * Inserter: no
 * Description: Heading and intro of the blog page (home.html).
 *
 * @package Candela\Theme
 */

?>
<!-- wp:group {"className":"candela-sectiune","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group candela-sectiune" style="margin-bottom:var(--wp--preset--spacing--40)"><!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center"><?php echo esc_html__( 'From the parish blog', 'candela' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"italic"}},"textColor":"gold"} -->
<p class="has-text-align-center has-gold-color has-text-color" style="font-style:italic"><?php echo esc_html__( 'Words of help, catechesis and news from the life of the parish.', 'candela' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
