<?php
/**
 * Candela theme. Presentation only: the only code here loads the stylesheet.
 *
 * @package Candela\Theme
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		$tema = wp_get_theme();
		wp_enqueue_style( 'candela', get_stylesheet_uri(), array(), $tema->get( 'Version' ) );
	}
);

add_action(
	'after_setup_theme',
	static function (): void {
		add_editor_style( 'style.css' );
		load_theme_textdomain( 'candela', get_template_directory() . '/languages' );
	}
);

/**
 * Block templates cannot call __(), so their few fixed texts are written in English and translated here,
 * when the block is rendered (Romanian sites get Romanian from languages/ro_RO).
 */
add_filter(
	'render_block',
	static function ( string $html ): string {
		static $texte = null;
		if ( null === $texte ) {
			$texte = array(
				'Names for prayer'                                => __( 'Names for prayer', 'candela' ),
				'Website made with Candela Parohiei'              => __( 'Website made with Candela Parohiei', 'candela' ),
				'Page not found'                                  => __( 'Page not found', 'candela' ),
				'It may have moved. Try the home page or search.' => __( 'It may have moved. Try the home page or search.', 'candela' ),
				'Search the site'                                 => __( 'Search the site', 'candela' ),
				'Search'                                          => __( 'Search', 'candela' ),
				'Read more'                                       => __( 'Read more', 'candela' ),
				'No articles yet.'                                => __( 'No articles yet.', 'candela' ),
			);
		}
		foreach ( $texte as $en => $tradus ) {
			if ( $en !== $tradus && false !== strpos( $html, '>' . $en . '<' ) ) {
				$html = str_replace( '>' . $en . '<', '>' . esc_html( $tradus ) . '<', $html );
			}
		}
		return $html;
	}
);

